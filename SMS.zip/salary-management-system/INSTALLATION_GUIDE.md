# Salary Management System - Complete Installation Guide

## Table of Contents
1. [System Requirements](#system-requirements)
2. [Installation Steps](#installation-steps)
3. [Database Setup](#database-setup)
4. [Backend Configuration](#backend-configuration)
5. [Frontend Setup](#frontend-setup)
6. [Deployment](#deployment)
7. [Testing](#testing)
8. [Troubleshooting](#troubleshooting)

---

## System Requirements

### Minimum Requirements
- **OS**: Windows 10/11, macOS 10.15+, Ubuntu 18.04+
- **RAM**: 4GB
- **Storage**: 2GB free space
- **CPU**: Dual-core processor

### Software Requirements
| Software | Version | Purpose |
|----------|---------|---------|
| Java JDK | 8 or higher | Backend compilation & execution |
| MySQL Server | 5.7+ | Database management |
| Apache Tomcat | 8.5+ | Web server & servlet container |
| Git | Latest | Version control (optional) |
| VS Code | Latest | Code editor |

### Download Links
- **Java JDK**: https://www.oracle.com/java/technologies/downloads/
- **MySQL**: https://dev.mysql.com/downloads/mysql/
- **Apache Tomcat**: https://tomcat.apache.org/download-80.cgi
- **VS Code**: https://code.visualstudio.com/

---

## Installation Steps

### Step 1: Install Java JDK

#### Windows
1. Download JDK 8+ from Oracle website
2. Run installer (.exe file)
3. Follow installation wizard
4. Set JAVA_HOME environment variable:
   - Right-click "This PC" → Properties
   - Click "Advanced system settings"
   - Click "Environment Variables"
   - Create new variable:
     - Variable name: `JAVA_HOME`
     - Variable value: `C:\Program Files\Java\jdk1.8.0_xxx`
5. Verify installation:
   ```cmd
   java -version
   javac -version
   ```

#### macOS
```bash
# Using Homebrew
brew install openjdk@8

# Or download from Oracle and run installer
```

#### Ubuntu/Linux
```bash
sudo apt update
sudo apt install openjdk-8-jdk openjdk-8-jre
java -version
```

### Step 2: Install MySQL

#### Windows
1. Download MySQL installer
2. Run installer
3. Choose setup type: Developer Default
4. Follow MySQL Server Configuration wizard
5. Set root password (remember it!)
6. Configure MySQL as service
7. Test connection:
   ```cmd
   mysql -u root -p
   ```

#### macOS
```bash
brew install mysql
brew services start mysql
mysql -u root
```

#### Ubuntu/Linux
```bash
sudo apt update
sudo apt install mysql-server
sudo mysql_secure_installation
```

### Step 3: Install Apache Tomcat

#### Windows
1. Download Tomcat ZIP file (not installer)
2. Extract to `C:\tomcat` (or your preferred location)
3. Set CATALINA_HOME environment variable:
   - Variable name: `CATALINA_HOME`
   - Variable value: `C:\tomcat`
4. Start Tomcat:
   - Go to `C:\tomcat\bin`
   - Run `startup.bat`
5. Access Tomcat: http://localhost:8080

#### macOS/Linux
```bash
# Using Homebrew (macOS)
brew install tomcat

# Or download and extract
tar xzf apache-tomcat-9.x.x.tar.gz
cd apache-tomcat-9.x.x

# Start Tomcat
./bin/startup.sh

# Access at http://localhost:8080
```

### Step 4: Install Git (Optional)
Download from https://git-scm.com/ and follow installation steps.

---

## Database Setup

### Step 1: Create Database and Tables

#### Option A: Using MySQL Command Line
```bash
# Connect to MySQL
mysql -u root -p

# Create database
CREATE DATABASE salary_management_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE salary_management_db;

# Import SQL file
source /path/to/salary_management.sql;

# Verify tables
SHOW TABLES;
```

#### Option B: Using MySQL Workbench
1. Open MySQL Workbench
2. Create new connection (root)
3. Click on connection
4. File → Run SQL Script
5. Select `salary_management.sql`
6. Execute
7. Verify tables are created

#### Option C: Using Command Line
```bash
mysql -u root -p salary_management_db < path/to/salary_management.sql
```

### Step 2: Verify Database Setup
```sql
USE salary_management_db;

-- Check tables
SHOW TABLES;

-- Check sample data
SELECT * FROM users;
SELECT * FROM organization_settings;
```

### Step 3: Backup Database (Optional)
```bash
mysqldump -u root -p salary_management_db > backup.sql
```

---

## Backend Configuration

### Step 1: Project Structure Setup

1. Create project directories:
```bash
mkdir -p salary-management-system/backend/src
mkdir -p salary-management-system/backend/lib
mkdir -p salary-management-system/backend/bin
mkdir -p salary-management-system/backend/web/WEB-INF
```

2. Copy all Java source files to `backend/src/`
3. Copy SQL schema to `database/`

### Step 2: Download Required JAR Libraries

Download these JAR files and place in `backend/lib/`:

1. **MySQL Connector** (mysql-connector-java-8.0.33.jar)
   - Download from: https://dev.mysql.com/downloads/connector/j/

2. **iText PDF** (itext-7.2.1.jar)
   - Download from: https://itextpdf.com/en/download

3. **JSON Simple** (json-simple-1.1.1.jar)
   - Download from: https://code.google.com/archive/p/json-simple/

```bash
# Or use wget
cd backend/lib

# MySQL Connector
wget https://dev.mysql.com/get/Downloads/Connector-J/mysql-connector-java-8.0.33.jar

# iText
wget https://github.com/itext/itext7/releases/download/7.2.1/itext7-7.2.1.jar

# JSON Simple
wget https://repo1.maven.org/maven2/com/googlecode/json-simple/json-simple/1.1.1/json-simple-1.1.1.jar
```

### Step 3: Update Database Connection

Edit `backend/src/com/salary/util/DatabaseConnection.java`:

```java
private static final String DB_URL = "jdbc:mysql://localhost:3306/salary_management_db";
private static final String DB_USER = "root";
private static final String DB_PASSWORD = "your_password_here";  // Set your MySQL root password
```

### Step 4: Compile Java Files

```bash
cd backend

# Compile all Java files
javac -cp "lib/*" -d bin src/com/salary/**/*.java src/com/salary/**/**/*.java

# Or compile individually (if above doesn't work)
javac -cp "lib/*:lib/mysql-connector-java-8.0.33.jar:lib/itext-7.2.1.jar:lib/json-simple-1.1.1.jar" \
  -d bin src/com/salary/util/*.java src/com/salary/model/*.java src/com/salary/servlet/*.java
```

### Step 5: Create WAR File

```bash
cd backend

# Create directory structure for WAR
mkdir -p war/WEB-INF/lib
mkdir -p war/WEB-INF/classes

# Copy compiled classes
cp -r bin/com war/WEB-INF/classes/

# Copy libraries
cp lib/*.jar war/WEB-INF/lib/

# Copy web.xml
cp web/WEB-INF/web.xml war/WEB-INF/

# Create WAR file
jar cvf salary-management.war -C war .

# Verify WAR
jar tf salary-management.war | head -20
```

### Step 6: Deploy to Tomcat

```bash
# Copy WAR to Tomcat
cp backend/salary-management.war /path/to/tomcat/webapps/

# Tomcat will auto-extract on startup
# If Tomcat is running, restart it:
# Windows: catalina.bat stop && catalina.bat start
# Linux/Mac: ./catalina.sh stop && ./catalina.sh start
```

### Step 7: Verify Backend Deployment

1. Start Tomcat if not already running
2. Open browser and visit:
   ```
   http://localhost:8080/salary-management
   ```
3. Should return an error (expected, no GET handler yet)
4. Check Tomcat logs:
   ```
   /path/to/tomcat/logs/catalina.out
   ```

---

## Frontend Setup

### Step 1: Copy Frontend Files

Copy all frontend files to a web server directory:

**Windows with XAMPP:**
```
C:\xampp\htdocs\salary-management\
```

**Windows with WAMP:**
```
C:\wamp\www\salary-management\
```

**Linux/Mac:**
```bash
sudo cp -r frontend/* /var/www/html/salary-management/
sudo chown -R www-data:www-data /var/www/html/salary-management/
```

### Step 2: Update API Configuration

Edit `frontend/js/auth.js` and `frontend/js/api.js`:

```javascript
this.apiUrl = 'http://localhost:8080/salary-management';
```

If deploying to different server:
```javascript
this.apiUrl = 'http://your-server-ip:8080/salary-management';
```

### Step 3: Start Frontend Development Server

#### Option A: Using VS Code Live Server
1. Install "Live Server" extension
2. Right-click on `index.html`
3. Select "Open with Live Server"
4. Opens at `http://localhost:5500`

#### Option B: Using Python
```bash
cd frontend

# Python 3
python -m http.server 3000

# Python 2
python -m SimpleHTTPServer 3000
```

#### Option C: Using Node.js
```bash
cd frontend

# Install http-server (one-time)
npm install -g http-server

# Run server
http-server -p 3000
```

#### Option D: Using XAMPP/WAMP
1. Place files in webroot
2. Start Apache from control panel
3. Visit `http://localhost/salary-management`

### Step 4: Test Frontend

Open browser and navigate to:
- http://localhost:3000 (if using dev server)
- http://localhost/salary-management (if using XAMPP)

Should see login page with:
- Login form
- Create account option
- Admin login button

---

## Deployment

### Production Deployment

#### Step 1: Security Hardening

Update `DatabaseConnection.java`:
```java
// Use environment variables instead of hardcoding
String dbPassword = System.getenv("DB_PASSWORD");
```

Update `web.xml`:
```xml
<session-config>
    <cookie-config>
        <secure>true</secure>
        <http-only>true</http-only>
    </cookie-config>
</session-config>
```

#### Step 2: Configure HTTPS

1. Generate SSL certificate:
```bash
keytool -genkey -alias tomcat -keyalg RSA -keystore keystore.jks
```

2. Edit `tomcat/conf/server.xml`:
```xml
<Connector port="8443" protocol="org.apache.coyote.http11.Http11NioProtocol"
           keyStoreFile="/path/to/keystore.jks"
           keyStorePass="password"
           scheme="https" secure="true"/>
```

#### Step 3: Update Frontend API URL
```javascript
this.apiUrl = 'https://your-domain.com:8443/salary-management';
```

#### Step 4: Deploy to Server

```bash
# SSH to server
ssh user@your-server.com

# Create application directory
mkdir -p /opt/salary-management

# Upload files (from local machine)
scp -r backend/salary-management.war user@your-server.com:/opt/salary-management/
scp -r frontend/* user@your-server.com:/var/www/html/salary-management/

# Deploy WAR
cp /opt/salary-management/salary-management.war $CATALINA_HOME/webapps/

# Restart Tomcat
$CATALINA_HOME/bin/shutdown.sh
$CATALINA_HOME/bin/startup.sh
```

---

## Testing

### Step 1: Test Database Connection

Create test file `TestConnection.java`:
```java
public class TestConnection {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("MySQL Driver loaded successfully!");
            
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/salary_management_db",
                "root", "password");
            System.out.println("Database connected successfully!");
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
```

### Step 2: Test Backend API

Using cURL:
```bash
# Test registration
curl -X POST http://localhost:8080/salary-management/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@email.com","password":"Test@123"}'

# Test login
curl -X POST http://localhost:8080/salary-management/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@salary.com","password":"admin123"}'
```

### Step 3: Test Frontend

1. Open browser to frontend URL
2. Register new account
3. Login with credentials
4. Create salary slip
5. Download PDF
6. View charts

### Step 4: Test Admin Functions

1. Login with admin credentials:
   - Email: `admin@salary.com`
   - Password: `admin123`
2. Access admin panel
3. View employees
4. Generate reports

---

## Troubleshooting

### Issue: Cannot Connect to MySQL
```
Error: Communications link failure
```
**Solution:**
- Verify MySQL is running: `mysql -u root -p`
- Check database credentials in code
- Ensure database exists: `SHOW DATABASES;`

### Issue: JAR Files Not Found
```
Error: ClassNotFoundException
```
**Solution:**
- Verify JAR files in `lib/` folder
- Check CLASSPATH includes `lib/*`
- Rebuild and redeploy WAR

### Issue: Port Already in Use
```
Error: Address already in use
```
**Solution:**
```bash
# Find process using port 8080
netstat -ano | findstr :8080  # Windows
lsof -i :8080  # Mac/Linux

# Kill process or change port in server.xml
```

### Issue: CORS Error in Browser
```
No 'Access-Control-Allow-Origin' header
```
**Solution:**
- Verify CORSFilter in web.xml
- Check response headers include:
  ```
  Access-Control-Allow-Origin: *
  ```

### Issue: PDF Generation Fails
```
Error: itext jar not found
```
**Solution:**
- Download iText JAR: https://itextpdf.com/
- Place in `backend/lib/`
- Recompile and redeploy

### Issue: Login Not Working
```
Invalid credentials error
```
**Solution:**
- Verify user exists: `SELECT * FROM users;`
- Check password hash: Use PasswordUtil
- Review database logs

### Issue: Static Files (CSS/JS) Not Loading
```
404 for css/style.css
```
**Solution:**
- Check file paths are correct
- Verify files are in correct directory
- Clear browser cache (Ctrl+Shift+R)

### Issue: Tomcat Startup Error
```
Address already in use
```
**Solution:**
```bash
# Change port in $CATALINA_HOME/conf/server.xml
<Connector port="8081" protocol="HTTP/1.1" ... />
```

---

## Quick Start Checklist

- [ ] Java JDK installed and verified
- [ ] MySQL installed and running
- [ ] Apache Tomcat installed
- [ ] Database created with tables
- [ ] JAR libraries downloaded
- [ ] Java files compiled
- [ ] WAR file created
- [ ] WAR deployed to Tomcat
- [ ] Frontend files copied
- [ ] API URL updated in JavaScript
- [ ] Frontend server running
- [ ] Can access login page
- [ ] Can register new account
- [ ] Can login with admin credentials
- [ ] Can create salary slip
- [ ] Can download PDF

---

## Next Steps

1. **Create Employee Records**
   - Login as admin
   - Create employee accounts
   - Set salary details

2. **Configure Organization**
   - Update company name
   - Configure tax rates
   - Set up bank details

3. **Generate Reports**
   - Create salary slips
   - Generate tax files
   - Create bank transfer files

4. **Monitor System**
   - Check logs regularly
   - Backup database
   - Monitor performance

---

For support, refer to:
- Code comments in source files
- API documentation
- Database schema documentation
- User guide

Good luck! 🚀
