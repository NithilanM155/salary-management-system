# Salary Management System - Project Structure

```
salary-management-system/
│
├── frontend/
│   ├── index.html                 # Login & Registration Page
│   ├── css/
│   │   ├── style.css              # Main styles
│   │   ├── login.css              # Login page styles
│   │   ├── dashboard.css          # Dashboard styles
│   │   └── responsive.css         # Responsive styles
│   ├── js/
│   │   ├── auth.js                # Authentication logic
│   │   ├── api.js                 # API communication
│   │   ├── dashboard.js           # Dashboard logic
│   │   ├── salary-calculator.js   # Salary calculation
│   │   └── charts.js              # Chart rendering
│   ├── pages/
│   │   ├── dashboard.html         # Employee dashboard
│   │   ├── salary-slip.html       # Salary slip form
│   │   └── admin-panel.html       # Admin dashboard
│   └── assets/
│       └── images/
│
├── backend/
│   ├── src/
│   │   └── com/
│   │       └── salary/
│   │           ├── servlet/
│   │           │   ├── LoginServlet.java
│   │           │   ├── RegisterServlet.java
│   │           │   ├── SalarySlipServlet.java
│   │           │   ├── DownloadServlet.java
│   │           │   └── AdminServlet.java
│   │           ├── controller/
│   │           │   ├── AuthController.java
│   │           │   ├── SalaryController.java
│   │           │   └── AdminController.java
│   │           ├── model/
│   │           │   ├── Employee.java
│   │           │   ├── SalarySlip.java
│   │           │   └── TaxData.java
│   │           ├── dao/
│   │           │   ├── EmployeeDAO.java
│   │           │   ├── SalarySlipDAO.java
│   │           │   └── TaxDAO.java
│   │           ├── service/
│   │           │   ├── SalaryService.java
│   │           │   ├── TaxService.java
│   │           │   └── PDFService.java
│   │           └── util/
│   │               ├── DatabaseConnection.java
│   │               ├── PasswordUtil.java
│   │               └── ValidationUtil.java
│   ├── lib/
│   │   ├── mysql-connector-java-8.0.33.jar
│   │   ├── itext-7.2.1.jar
│   │   └── json-simple-1.1.1.jar
│   └── web/
│       └── WEB-INF/
│           └── web.xml
│
├── database/
│   └── salary_management.sql      # Database schema
│
├── README.md
└── SETUP_GUIDE.md
```
