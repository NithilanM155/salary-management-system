-- Salary Management System Database Schema

CREATE DATABASE IF NOT EXISTS salary_management_db;
USE salary_management_db;

-- Users Table (Login credentials)
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    role ENUM('employee', 'admin') DEFAULT 'employee',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Employees Table
CREATE TABLE employees (
    employee_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    employee_code VARCHAR(50) UNIQUE NOT NULL,
    designation VARCHAR(100) NOT NULL,
    department VARCHAR(100),
    date_of_joining DATE,
    salary_per_hour DECIMAL(10, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Salary Slips Table
CREATE TABLE salary_slips (
    slip_id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    user_id INT NOT NULL,
    month INT NOT NULL,
    year INT NOT NULL,
    working_hours DECIMAL(10, 2),
    salary_per_hour DECIMAL(10, 2),
    basic_salary DECIMAL(12, 2),
    allowances DECIMAL(12, 2) DEFAULT 0,
    deductions DECIMAL(12, 2) DEFAULT 0,
    gross_salary DECIMAL(12, 2),
    tax_percentage DECIMAL(5, 2),
    tax_amount DECIMAL(12, 2),
    net_salary DECIMAL(12, 2),
    status ENUM('draft', 'finalized', 'paid') DEFAULT 'draft',
    slip_pdf_path VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    UNIQUE KEY unique_slip (employee_id, month, year)
);

-- Tax Records Table
CREATE TABLE tax_records (
    tax_id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    slip_id INT NOT NULL,
    month INT NOT NULL,
    year INT NOT NULL,
    taxable_amount DECIMAL(12, 2),
    tax_rate DECIMAL(5, 2),
    tax_amount DECIMAL(12, 2),
    status ENUM('pending', 'submitted', 'paid') DEFAULT 'pending',
    file_generated BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE CASCADE,
    FOREIGN KEY (slip_id) REFERENCES salary_slips(slip_id) ON DELETE CASCADE
);

-- Bank Transfer Records Table
CREATE TABLE bank_transfers (
    transfer_id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    slip_id INT NOT NULL,
    transfer_amount DECIMAL(12, 2),
    bank_account VARCHAR(50),
    ifsc_code VARCHAR(20),
    transfer_date DATE,
    status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
    file_generated BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE CASCADE,
    FOREIGN KEY (slip_id) REFERENCES salary_slips(slip_id) ON DELETE CASCADE
);

-- Organization Settings
CREATE TABLE organization_settings (
    setting_id INT PRIMARY KEY AUTO_INCREMENT,
    org_name VARCHAR(100),
    org_address VARCHAR(255),
    org_email VARCHAR(100),
    org_phone VARCHAR(20),
    bank_name VARCHAR(100),
    account_number VARCHAR(50),
    tax_id VARCHAR(50),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX idx_user_email ON users(email);
CREATE INDEX idx_employee_user ON employees(user_id);
CREATE INDEX idx_salary_employee ON salary_slips(employee_id);
CREATE INDEX idx_salary_year_month ON salary_slips(year, month);
CREATE INDEX idx_tax_employee ON tax_records(employee_id);
CREATE INDEX idx_transfer_employee ON bank_transfers(employee_id);

-- Insert default admin user (password: admin123 - hashed)
-- Password hash: $2a$10$Uf5wz... (bcrypt of 'admin123')
INSERT INTO users (email, name, password, role) 
VALUES ('admin@salary.com', 'System Admin', 'admin123', 'admin');

-- Insert organization settings
INSERT INTO organization_settings 
(org_name, org_address, org_email, org_phone, tax_id) 
VALUES 
('ABC Corporation', '123 Business Street, City', 'info@abccorp.com', '+91-9999999999', 'TAX123456');
