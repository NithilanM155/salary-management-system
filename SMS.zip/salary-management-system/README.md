# Salary Management System

A comprehensive, professional salary management system for organizations to calculate, manage, and process employee salaries with tax compliance and reporting features.

## 🎯 Features

### Employee Features
- ✅ User Registration & Login
- ✅ Salary Slip Generation
- ✅ Automatic Salary Calculation
- ✅ Monthly & Annual Reports
- ✅ Tax Calculation & Deductions
- ✅ PDF Salary Slip Download
- ✅ Salary History Tracking
- ✅ Data Visualization (Charts)
- ✅ Edit Salary Data
- ✅ Personal Dashboard

### Admin Features
- ✅ Employee Management
- ✅ Salary Monitoring
- ✅ Tax Management
- ✅ System Configuration
- ✅ Report Generation
- ✅ Tax File Generation (CSV)
- ✅ Bank File Generation (CSV)
- ✅ Organization Settings
- ✅ User Management
- ✅ Admin Dashboard

### System Features
- ✅ Secure Authentication
- ✅ Role-Based Access Control
- ✅ Database Management
- ✅ Responsive UI Design
- ✅ Professional Theme
- ✅ Error Handling
- ✅ Data Validation
- ✅ PDF Generation
- ✅ File Management

## 🏗️ Architecture

### Frontend
- **HTML5**: Semantic markup
- **CSS3**: Modern styling with animations
- **JavaScript (ES6+)**: Interactive features

### Backend
- **Java Servlets**: Request handling
- **JDBC**: Database connectivity
- **MySQL**: Data persistence
- **iText**: PDF generation

### Database
- **MySQL 5.7+**: Relational database
- Normalized schema
- Indexed queries
- Transactional integrity

## 📦 Project Structure

```
salary-management-system/
├── frontend/
│   ├── index.html
│   ├── css/
│   │   ├── style.css
│   │   ├── login.css
│   │   ├── dashboard.css
│   │   └── responsive.css
│   ├── js/
│   │   ├── auth.js
│   │   ├── api.js
│   │   ├── dashboard.js
│   │   ├── salary-calculator.js
│   │   └── charts.js
│   └── pages/
│       ├── dashboard.html
│       ├── salary-slip.html
│       └── admin-panel.html
├── backend/
│   ├── src/com/salary/
│   │   ├── servlet/
│   │   ├── controller/
│   │   ├── model/
│   │   ├── dao/
│   │   ├── service/
│   │   └── util/
│   ├── lib/
│   └── web/WEB-INF/web.xml
├── database/
│   └── salary_management.sql
└── documentation/
```

## 🚀 Quick Start

### Prerequisites
- JDK 8+
- MySQL 5.7+
- Apache Tomcat 8.5+
- VS Code or IDE

### Installation

1. **Clone/Download Project**
   ```bash
   git clone <repository-url>
   cd salary-management-system
   ```

2. **Setup Database**
   ```bash
   mysql -u root -p < database/salary_management.sql
   ```

3. **Compile Backend**
   ```bash
   cd backend
   javac -cp "lib/*" src/com/salary/**/*.java -d bin/
   ```

4. **Deploy to Tomcat**
   ```bash
   cp backend/bin/* /path/to/tomcat/webapps/salary-management/
   ```

5. **Start Frontend**
   - Open frontend/index.html in browser
   - Or use live server on port 3000

6. **Access Application**
   - Frontend: `http://localhost:3000`
   - Backend API: `http://localhost:8080/salary-management`

## 📚 API Endpoints

### Authentication
```
POST   /api/auth/register          - Register new user
POST   /api/auth/login             - User login
POST   /api/auth/admin-login       - Admin login
POST   /api/auth/logout            - Logout
```

### Employee
```
GET    /api/employee/profile       - Get profile
POST   /api/salary/create-slip     - Create salary slip
GET    /api/salary/slips           - Get all slips
GET    /api/salary/slip/{id}       - Get specific slip
PUT    /api/salary/slip/{id}       - Update slip
GET    /api/salary/slip/{id}/download - Download PDF
```

### Admin
```
GET    /api/admin/dashboard        - Dashboard data
GET    /api/admin/employees        - All employees
POST   /api/admin/employee         - Create employee
PUT    /api/admin/employee/{id}    - Update employee
DELETE /api/admin/employee/{id}    - Delete employee
GET    /api/admin/salary-slips     - All salary slips
GET    /api/admin/generate-tax-file - Download tax file
GET    /api/admin/generate-bank-file - Download bank file
```

## 🔐 Default Credentials

### Admin
- Email: `admin@salary.com`
- Password: `admin123`

## 💾 Database Schema

### Key Tables
- `users` - User accounts (employee/admin)
- `employees` - Employee information
- `salary_slips` - Monthly salary records
- `tax_records` - Tax calculations
- `bank_transfers` - Bank transfer details

## 🎨 UI Features

### Professional Design
- Modern gradient theme
- Responsive layout
- Smooth animations
- Intuitive navigation
- Mobile-friendly

### Color Scheme
- Primary: Blue (#2563eb)
- Secondary: Purple (#7c3aed)
- Success: Green (#10b981)
- Danger: Red (#ef4444)
- Warning: Amber (#f59e0b)

## 🔄 Workflow

### Employee Workflow
1. Register with email and password
2. Login to dashboard
3. Create salary slip with details
4. System calculates salary automatically
5. View and download salary slip PDF
6. View charts and reports
7. Edit previous salary records

### Admin Workflow
1. Login with admin credentials
2. Access admin panel
3. Manage employees
4. Monitor salary data
5. Generate reports
6. Create tax files
7. Create bank transfer files

## 📊 Salary Calculation

### Formula
```
Basic Salary = Working Hours × Salary Per Hour
Gross Salary = Basic Salary + Allowances
Tax Amount = Gross Salary × Tax Percentage
Net Salary = Gross Salary - Tax Amount - Deductions
```

### Tax Rates (Example)
- 0 - 250,000: 0%
- 250,001 - 500,000: 5%
- 500,001 - 1,000,000: 10%
- 1,000,001+: 20%

## 🛡️ Security Features

- Password hashing (SHA-256)
- Session management
- Input validation
- SQL injection prevention
- CSRF protection
- Authentication & Authorization
- Secure cookies
- HTTPS support (production)

## ⚙️ Configuration

### Database Connection
Edit `DatabaseConnection.java`:
```java
private static final String DB_URL = "jdbc:mysql://localhost:3306/salary_management_db";
private static final String DB_USER = "root";
private static final String DB_PASSWORD = "your_password";
```

### API URL
Edit `api.js`:
```javascript
this.baseUrl = 'http://localhost:8080/salary-management';
```

## 📱 Responsive Design

- Desktop: Full layout (1200px+)
- Tablet: Adjusted layout (768px - 1199px)
- Mobile: Single column (below 768px)

## 🐛 Troubleshooting

### Database Connection Error
- Verify MySQL is running
- Check credentials
- Ensure database exists

### API Not Responding
- Check Tomcat is running
- Verify API URL in JavaScript
- Check browser console for errors

### PDF Generation Error
- Verify iText JAR in lib folder
- Check file permissions
- Ensure temp folder exists

## 🔄 Future Enhancements

- [ ] Email notifications
- [ ] SMS alerts
- [ ] Multi-language support
- [ ] Mobile app
- [ ] Advanced analytics
- [ ] Biometric attendance
- [ ] Leave management
- [ ] Performance appraisal
- [ ] Payroll automation
- [ ] Document management

## 📖 Documentation

- `SETUP_GUIDE.md` - Installation & setup
- `API_DOCUMENTATION.md` - API reference
- `DATABASE_SCHEMA.md` - Database design
- `USER_GUIDE.md` - User manual

## 📄 File Formats

### Supported Downloads
- **PDF**: Salary slip, reports
- **CSV**: Tax records, bank transfers
- **Excel**: Salary reports

## 🎓 Learning Resources

- Java Servlets & JDBC
- MySQL Database Design
- Responsive Web Design
- JavaScript ES6+
- PDF Generation
- REST API Design

## 💬 Support

For questions or issues:
1. Check documentation
2. Review code comments
3. Check troubleshooting section
4. Contact development team

## 📝 License

This project is provided for educational purposes.

## 🙏 Acknowledgments

- Built with modern web technologies
- Professional UI/UX design
- Enterprise-grade features
- Production-ready code

---

**Version**: 1.0.0  
**Last Updated**: 2024  
**Status**: Ready for Use

### Key Highlights

✨ **Professional Theme** - Modern, gradient-based design  
⚡ **Performance** - Optimized queries and caching  
🔒 **Security** - Multi-layer security implementation  
📱 **Responsive** - Works on all devices  
📊 **Analytics** - Charts and detailed reports  
🎯 **User-Friendly** - Intuitive interface  
📚 **Well-Documented** - Complete documentation  
🔧 **Maintainable** - Clean, modular code  

---

Enjoy using the Salary Management System! 🚀
