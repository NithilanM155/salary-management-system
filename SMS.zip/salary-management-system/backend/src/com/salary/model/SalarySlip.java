package com.salary.model;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * SalarySlip Model
 * Represents a salary slip for an employee
 */
public class SalarySlip implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    // Status constants
    public static final String STATUS_DRAFT = "draft";
    public static final String STATUS_FINALIZED = "finalized";
    public static final String STATUS_PAID = "paid";
    
    private int slipId;
    private int employeeId;
    private int userId;
    private String employeeName;
    private String employeeCode;
    private int month;
    private int year;
    private double workingHours;
    private double salaryPerHour;
    private double basicSalary;
    private double allowances;
    private double deductions;
    private double grossSalary;
    private double taxPercentage;
    private double taxAmount;
    private double netSalary;
    private String status;
    private String slipPdfPath;
    private LocalDate createdAt;
    private LocalDate updatedAt;
    
    // Constructors
    public SalarySlip() {
    }
    
    public SalarySlip(int employeeId, int userId, int month, int year) {
        this.employeeId = employeeId;
        this.userId = userId;
        this.month = month;
        this.year = year;
        this.status = STATUS_DRAFT;
    }
    
    // Getters and Setters
    public int getSlipId() {
        return slipId;
    }
    
    public void setSlipId(int slipId) {
        this.slipId = slipId;
    }
    
    public int getEmployeeId() {
        return employeeId;
    }
    
    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }
    
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    public String getEmployeeName() {
        return employeeName;
    }
    
    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }
    
    public String getEmployeeCode() {
        return employeeCode;
    }
    
    public void setEmployeeCode(String employeeCode) {
        this.employeeCode = employeeCode;
    }
    
    public int getMonth() {
        return month;
    }
    
    public void setMonth(int month) {
        this.month = month;
    }
    
    public int getYear() {
        return year;
    }
    
    public void setYear(int year) {
        this.year = year;
    }
    
    public double getWorkingHours() {
        return workingHours;
    }
    
    public void setWorkingHours(double workingHours) {
        this.workingHours = workingHours;
    }
    
    public double getSalaryPerHour() {
        return salaryPerHour;
    }
    
    public void setSalaryPerHour(double salaryPerHour) {
        this.salaryPerHour = salaryPerHour;
    }
    
    public double getBasicSalary() {
        return basicSalary;
    }
    
    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }
    
    public double getAllowances() {
        return allowances;
    }
    
    public void setAllowances(double allowances) {
        this.allowances = allowances;
    }
    
    public double getDeductions() {
        return deductions;
    }
    
    public void setDeductions(double deductions) {
        this.deductions = deductions;
    }
    
    public double getGrossSalary() {
        return grossSalary;
    }
    
    public void setGrossSalary(double grossSalary) {
        this.grossSalary = grossSalary;
    }
    
    public double getTaxPercentage() {
        return taxPercentage;
    }
    
    public void setTaxPercentage(double taxPercentage) {
        this.taxPercentage = taxPercentage;
    }
    
    public double getTaxAmount() {
        return taxAmount;
    }
    
    public void setTaxAmount(double taxAmount) {
        this.taxAmount = taxAmount;
    }
    
    public double getNetSalary() {
        return netSalary;
    }
    
    public void setNetSalary(double netSalary) {
        this.netSalary = netSalary;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getSlipPdfPath() {
        return slipPdfPath;
    }
    
    public void setSlipPdfPath(String slipPdfPath) {
        this.slipPdfPath = slipPdfPath;
    }
    
    public LocalDate getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDate createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDate getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDate updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    // Utility methods
    public boolean isComplete() {
        return slipId > 0 && employeeId > 0 && 
               grossSalary > 0 && netSalary > 0;
    }
    
    public boolean isDraft() {
        return STATUS_DRAFT.equals(status);
    }
    
    public boolean isFinalized() {
        return STATUS_FINALIZED.equals(status);
    }
    
    public boolean isPaid() {
        return STATUS_PAID.equals(status);
    }
    
    public String getMonthYearString() {
        String[] months = {"", "January", "February", "March", "April", "May", "June",
                          "July", "August", "September", "October", "November", "December"};
        return months[month] + " " + year;
    }
    
    @Override
    public String toString() {
        return "SalarySlip{" +
                "slipId=" + slipId +
                ", employeeId=" + employeeId +
                ", month=" + month +
                ", year=" + year +
                ", grossSalary=" + grossSalary +
                ", netSalary=" + netSalary +
                ", status='" + status + '\'' +
                '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        SalarySlip that = (SalarySlip) o;
        return slipId == that.slipId &&
               employeeId == that.employeeId &&
               month == that.month &&
               year == that.year;
    }
    
    @Override
    public int hashCode() {
        return Integer.hashCode(slipId);
    }
}
