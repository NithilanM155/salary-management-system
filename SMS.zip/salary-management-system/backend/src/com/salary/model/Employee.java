package com.salary.model;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * Employee Model
 * Represents an employee in the system
 */
public class Employee implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int employeeId;
    private int userId;
    private String employeeCode;
    private String name;
    private String email;
    private String designation;
    private String department;
    private LocalDate dateOfJoining;
    private double salaryPerHour;
    private String phoneNumber;
    private String address;
    private LocalDate createdAt;
    private LocalDate updatedAt;
    
    // Constructors
    public Employee() {
    }
    
    public Employee(int userId, String employeeCode, String name, String designation) {
        this.userId = userId;
        this.employeeCode = employeeCode;
        this.name = name;
        this.designation = designation;
    }
    
    public Employee(int employeeId, int userId, String employeeCode, String name, 
                    String designation, double salaryPerHour) {
        this.employeeId = employeeId;
        this.userId = userId;
        this.employeeCode = employeeCode;
        this.name = name;
        this.designation = designation;
        this.salaryPerHour = salaryPerHour;
    }
    
    // Getters and Setters
    public int getEmployeeId() {
        return employeeId;
    }
    
    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }
    
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    public String getEmployeeCode() {
        return employeeCode;
    }
    
    public void setEmployeeCode(String employeeCode) {
        this.employeeCode = employeeCode;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getDesignation() {
        return designation;
    }
    
    public void setDesignation(String designation) {
        this.designation = designation;
    }
    
    public String getDepartment() {
        return department;
    }
    
    public void setDepartment(String department) {
        this.department = department;
    }
    
    public LocalDate getDateOfJoining() {
        return dateOfJoining;
    }
    
    public void setDateOfJoining(LocalDate dateOfJoining) {
        this.dateOfJoining = dateOfJoining;
    }
    
    public double getSalaryPerHour() {
        return salaryPerHour;
    }
    
    public void setSalaryPerHour(double salaryPerHour) {
        this.salaryPerHour = salaryPerHour;
    }
    
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public LocalDate getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDate createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDate getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDate updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    // Utility methods
    public boolean isComplete() {
        return employeeId > 0 && userId > 0 && 
               employeeCode != null && !employeeCode.isEmpty() &&
               name != null && !name.isEmpty() &&
               designation != null && !designation.isEmpty();
    }
    
    @Override
    public String toString() {
        return "Employee{" +
                "employeeId=" + employeeId +
                ", userId=" + userId +
                ", employeeCode='" + employeeCode + '\'' +
                ", name='" + name + '\'' +
                ", designation='" + designation + '\'' +
                ", salaryPerHour=" + salaryPerHour +
                '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        Employee employee = (Employee) o;
        return employeeId == employee.employeeId &&
               userId == employee.userId;
    }
    
    @Override
    public int hashCode() {
        return Integer.hashCode(employeeId);
    }
}
