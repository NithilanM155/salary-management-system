package com.salary.model;
import java.io.Serializable;
public class User implements Serializable {
    private int userId; private String email; private String password; private String name; private String role;
    public User() {}
    public int getUserId() { return userId; } public void setUserId(int userId) { this.userId = userId; }
    public String getEmail() { return email; } public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; } public void setPassword(String password) { this.password = password; }
    public String getName() { return name; } public void setName(String name) { this.name = name; }
    public String getRole() { return role; } public void setRole(String role) { this.role = role; }
}
