package com.salary.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * Response Model
 * Generic response object for API responses
 */
public class Response<T> implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private boolean success;
    private String message;
    private T data;
    private Map<String, String> errors;
    private long timestamp;
    
    // Constructors
    public Response() {
        this.timestamp = System.currentTimeMillis();
        this.errors = new HashMap<>();
    }
    
    public Response(boolean success, String message) {
        this();
        this.success = success;
        this.message = message;
    }
    
    public Response(boolean success, String message, T data) {
        this();
        this.success = success;
        this.message = message;
        this.data = data;
    }
    
    // Static factory methods
    public static <T> Response<T> success(String message, T data) {
        return new Response<>(true, message, data);
    }
    
    public static <T> Response<T> success(String message) {
        return new Response<>(true, message, null);
    }
    
    public static <T> Response<T> error(String message) {
        return new Response<>(false, message, null);
    }
    
    public static <T> Response<T> error(String message, Map<String, String> errors) {
        Response<T> response = new Response<>(false, message, null);
        response.setErrors(errors);
        return response;
    }
    
    // Getters and Setters
    public boolean isSuccess() {
        return success;
    }
    
    public void setSuccess(boolean success) {
        this.success = success;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public T getData() {
        return data;
    }
    
    public void setData(T data) {
        this.data = data;
    }
    
    public Map<String, String> getErrors() {
        return errors;
    }
    
    public void setErrors(Map<String, String> errors) {
        this.errors = errors;
    }
    
    public void addError(String field, String message) {
        this.errors.put(field, message);
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
    
    @Override
    public String toString() {
        return "Response{" +
                "success=" + success +
                ", message='" + message + '\'' +
                ", data=" + data +
                ", errors=" + errors +
                ", timestamp=" + timestamp +
                '}';
    }
}
