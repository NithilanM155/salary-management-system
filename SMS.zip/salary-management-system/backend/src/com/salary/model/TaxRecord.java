package com.salary.model;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * TaxRecord Model
 * Represents tax information for an employee
 */
public class TaxRecord implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    // Status constants
    public static final String STATUS_PENDING = "pending";
    public static final String STATUS_SUBMITTED = "submitted";
    public static final String STATUS_PAID = "paid";
    
    private int taxId;
    private int employeeId;
    private int slipId;
    private int month;
    private int year;
    private double taxableAmount;
    private double taxRate;
    private double taxAmount;
    private String status;
    private boolean fileGenerated;
    private LocalDate createdAt;
    
    // Constructors
    public TaxRecord() {
    }
    
    public TaxRecord(int employeeId, int slipId, int month, int year, double taxAmount) {
        this.employeeId = employeeId;
        this.slipId = slipId;
        this.month = month;
        this.year = year;
        this.taxAmount = taxAmount;
        this.status = STATUS_PENDING;
    }
    
    // Getters and Setters
    public int getTaxId() {
        return taxId;
    }
    
    public void setTaxId(int taxId) {
        this.taxId = taxId;
    }
    
    public int getEmployeeId() {
        return employeeId;
    }
    
    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }
    
    public int getSlipId() {
        return slipId;
    }
    
    public void setSlipId(int slipId) {
        this.slipId = slipId;
    }
    
    public int getMonth() {
        return month;
    }
    
    public void setMonth(int month) {
        this.month = month;
    }
    
    public int getYear() {
        return year;
    }
    
    public void setYear(int year) {
        this.year = year;
    }
    
    public double getTaxableAmount() {
        return taxableAmount;
    }
    
    public void setTaxableAmount(double taxableAmount) {
        this.taxableAmount = taxableAmount;
    }
    
    public double getTaxRate() {
        return taxRate;
    }
    
    public void setTaxRate(double taxRate) {
        this.taxRate = taxRate;
    }
    
    public double getTaxAmount() {
        return taxAmount;
    }
    
    public void setTaxAmount(double taxAmount) {
        this.taxAmount = taxAmount;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public boolean isFileGenerated() {
        return fileGenerated;
    }
    
    public void setFileGenerated(boolean fileGenerated) {
        this.fileGenerated = fileGenerated;
    }
    
    public LocalDate getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDate createdAt) {
        this.createdAt = createdAt;
    }
    
    // Utility methods
    public boolean isPending() {
        return STATUS_PENDING.equals(status);
    }
    
    public boolean isSubmitted() {
        return STATUS_SUBMITTED.equals(status);
    }
    
    public boolean isPaid() {
        return STATUS_PAID.equals(status);
    }
    
    public String getMonthYearString() {
        String[] months = {"", "January", "February", "March", "April", "May", "June",
                          "July", "August", "September", "October", "November", "December"};
        return months[month] + " " + year;
    }
    
    @Override
    public String toString() {
        return "TaxRecord{" +
                "taxId=" + taxId +
                ", employeeId=" + employeeId +
                ", month=" + month +
                ", year=" + year +
                ", taxAmount=" + taxAmount +
                ", status='" + status + '\'' +
                '}';
    }
}
