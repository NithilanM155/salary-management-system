package com.salary.util;

import java.util.regex.Pattern;

/**
 * Validation Utility
 * Provides various input validation methods
 */
public class ValidationUtil {
    
    // Regex patterns
    private static final String EMAIL_PATTERN = "^[A-Za-z0-9+_.-]+@(.+)$";
    private static final String PHONE_PATTERN = "^[0-9]{10}$";
    private static final String NUMERIC_PATTERN = "^[0-9]+$";
    private static final String ALPHANUMERIC_PATTERN = "^[a-zA-Z0-9]+$";
    
    /**
     * Validate email address
     * @param email Email to validate
     * @return True if valid email
     */
    public static boolean isValidEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        return Pattern.matches(EMAIL_PATTERN, email);
    }
    
    /**
     * Validate phone number (10 digits)
     * @param phone Phone number to validate
     * @return True if valid phone
     */
    public static boolean isValidPhone(String phone) {
        if (phone == null || phone.trim().isEmpty()) {
            return false;
        }
        return Pattern.matches(PHONE_PATTERN, phone.replaceAll("[^0-9]", ""));
    }
    
    /**
     * Validate if string is numeric
     * @param str String to check
     * @return True if numeric
     */
    public static boolean isNumeric(String str) {
        if (str == null || str.trim().isEmpty()) {
            return false;
        }
        return Pattern.matches(NUMERIC_PATTERN, str);
    }
    
    /**
     * Validate if string is alphanumeric
     * @param str String to check
     * @return True if alphanumeric
     */
    public static boolean isAlphanumeric(String str) {
        if (str == null || str.trim().isEmpty()) {
            return false;
        }
        return Pattern.matches(ALPHANUMERIC_PATTERN, str);
    }
    
    /**
     * Validate if string is not empty
     * @param str String to check
     * @return True if not empty
     */
    public static boolean isNotEmpty(String str) {
        return str != null && !str.trim().isEmpty();
    }
    
    /**
     * Validate minimum length
     * @param str String to check
     * @param minLength Minimum required length
     * @return True if meets minimum length
     */
    public static boolean hasMinLength(String str, int minLength) {
        return str != null && str.length() >= minLength;
    }
    
    /**
     * Validate maximum length
     * @param str String to check
     * @param maxLength Maximum allowed length
     * @return True if within maximum length
     */
    public static boolean hasMaxLength(String str, int maxLength) {
        return str != null && str.length() <= maxLength;
    }
    
    /**
     * Validate salary amount
     * @param salary Salary to validate
     * @return True if valid salary
     */
    public static boolean isValidSalary(double salary) {
        return salary > 0 && salary < Double.MAX_VALUE;
    }
    
    /**
     * Validate percentage (0-100)
     * @param percentage Percentage to validate
     * @return True if valid percentage
     */
    public static boolean isValidPercentage(double percentage) {
        return percentage >= 0 && percentage <= 100;
    }
    
    /**
     * Validate year
     * @param year Year to validate
     * @return True if valid year
     */
    public static boolean isValidYear(int year) {
        int currentYear = java.time.Year.now().getValue();
        return year > 1900 && year <= currentYear;
    }
    
    /**
     * Validate month (1-12)
     * @param month Month to validate
     * @return True if valid month
     */
    public static boolean isValidMonth(int month) {
        return month >= 1 && month <= 12;
    }
    
    /**
     * Validate day for given month and year
     * @param day Day to validate
     * @param month Month (1-12)
     * @param year Year
     * @return True if valid day
     */
    public static boolean isValidDay(int day, int month, int year) {
        if (day < 1) return false;
        
        int daysInMonth = getDaysInMonth(month, year);
        return day <= daysInMonth;
    }
    
    /**
     * Get number of days in a month
     * @param month Month (1-12)
     * @param year Year
     * @return Number of days
     */
    private static int getDaysInMonth(int month, int year) {
        switch (month) {
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                return 31;
            case 4: case 6: case 9: case 11:
                return 30;
            case 2:
                return isLeapYear(year) ? 29 : 28;
            default:
                return 0;
        }
    }
    
    /**
     * Check if year is leap year
     * @param year Year to check
     * @return True if leap year
     */
    private static boolean isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }
    
    /**
     * Sanitize input to prevent SQL injection
     * @param input Input string to sanitize
     * @return Sanitized string
     */
    public static String sanitizeInput(String input) {
        if (input == null) {
            return null;
        }
        return input.replaceAll("[';\"\\\\]", "");
    }
    
    /**
     * Validate employee ID format
     * @param employeeId Employee ID to validate
     * @return True if valid format
     */
    public static boolean isValidEmployeeId(String employeeId) {
        return isNotEmpty(employeeId) && employeeId.matches("^EMP[0-9]{5}$");
    }
    
    /**
     * Generate employee ID
     * @param counter Sequential counter
     * @return Generated employee ID
     */
    public static String generateEmployeeId(int counter) {
        return String.format("EMP%05d", counter);
    }
    
    /**
     * Validate working hours
     * @param hours Hours to validate
     * @return True if valid hours
     */
    public static boolean isValidWorkingHours(double hours) {
        return hours > 0 && hours <= 24 * 30; // Max 30 days of 24 hours
    }
    
    /**
     * Validate salary per hour
     * @param salaryPerHour Hourly salary to validate
     * @return True if valid
     */
    public static boolean isValidSalaryPerHour(double salaryPerHour) {
        return salaryPerHour > 0 && salaryPerHour < 100000;
    }
}
