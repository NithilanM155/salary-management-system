package com.salary.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Password Utility
 * Handles password hashing and validation
 */
public class PasswordUtil {
    
    private static final int SALT_LENGTH = 16;
    
    /**
     * Generate a secure salt
     * @return Base64 encoded salt
     */
    public static String generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[SALT_LENGTH];
        random.nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }
    
    /**
     * Hash password with SHA-256
     * @param password Plain text password
     * @return Hashed password
     */
    public static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] messageDigest = md.digest(password.getBytes());
            
            // Convert bytes to hexadecimal string
            StringBuilder sb = new StringBuilder();
            for (byte b : messageDigest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not found", e);
        }
    }
    
    /**
     * Hash password with salt
     * @param password Plain text password
     * @param salt Salt string
     * @return Hashed password with salt
     */
    public static String hashPasswordWithSalt(String password, String salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            String input = password + salt;
            byte[] messageDigest = md.digest(input.getBytes());
            
            StringBuilder sb = new StringBuilder();
            for (byte b : messageDigest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not found", e);
        }
    }
    
    /**
     * Verify password
     * @param plainPassword Plain text password from user
     * @param hashedPassword Hashed password from database
     * @return True if password matches
     */
    public static boolean verifyPassword(String plainPassword, String hashedPassword) {
        String hash = hashPassword(plainPassword);
        return hash.equals(hashedPassword);
    }
    
    /**
     * Verify password with salt
     * @param plainPassword Plain text password from user
     * @param hashedPassword Hashed password from database
     * @param salt Salt from database
     * @return True if password matches
     */
    public static boolean verifyPasswordWithSalt(String plainPassword, String hashedPassword, String salt) {
        String hash = hashPasswordWithSalt(plainPassword, salt);
        return hash.equals(hashedPassword);
    }
    
    /**
     * Check if password is strong
     * Requirements:
     * - At least 8 characters
     * - Contains uppercase letter
     * - Contains lowercase letter
     * - Contains number
     * - Contains special character (optional)
     * 
     * @param password Password to check
     * @return True if password is strong
     */
    public static boolean isStrongPassword(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }
        
        boolean hasUppercase = password.matches(".*[A-Z].*");
        boolean hasLowercase = password.matches(".*[a-z].*");
        boolean hasDigit = password.matches(".*\\d.*");
        boolean hasSpecial = password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>?].*");
        
        return hasUppercase && hasLowercase && hasDigit;
    }
    
    /**
     * Get password strength level
     * @param password Password to check
     * @return Strength level: WEAK, MEDIUM, STRONG
     */
    public static String getPasswordStrength(String password) {
        if (password == null || password.length() < 6) {
            return "WEAK";
        }
        
        int strength = 0;
        
        if (password.length() >= 8) strength++;
        if (password.matches(".*[A-Z].*")) strength++;
        if (password.matches(".*[a-z].*")) strength++;
        if (password.matches(".*\\d.*")) strength++;
        if (password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>?].*")) strength++;
        
        if (strength <= 2) return "WEAK";
        if (strength <= 3) return "MEDIUM";
        return "STRONG";
    }
}
