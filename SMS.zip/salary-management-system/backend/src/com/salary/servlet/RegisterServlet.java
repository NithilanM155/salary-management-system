package com.salary.servlet;
import com.salary.dao.UserDAO;
import com.salary.model.User;
import com.salary.util.PasswordUtil;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.*;
public class RegisterServlet extends HttpServlet {
    private UserDAO userDAO = new UserDAO();
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("application/json"); PrintWriter out = res.getWriter(); JSONObject json = new JSONObject();
        try {
            StringBuilder sb = new StringBuilder(); BufferedReader reader = req.getReader(); String line;
            while ((line = reader.readLine()) != null) sb.append(line);
            JSONObject body = (JSONObject) new JSONParser().parse(sb.toString());
            String name=(String)body.get("name"); String email=(String)body.get("email"); String password=(String)body.get("password");
            if (name==null||email==null||password==null) { json.put("success",false); json.put("message","All fields required"); res.setStatus(400); out.print(json.toJSONString()); return; }
            if (userDAO.findByEmail(email)!=null) { json.put("success",false); json.put("message","Email already registered"); res.setStatus(409); out.print(json.toJSONString()); return; }
            User user = new User(); user.setName(name); user.setEmail(email); user.setPassword(PasswordUtil.hashPassword(password)); user.setRole("employee");
            json.put("success", userDAO.create(user)); json.put("message","Account created");
        } catch (Exception e) { json.put("success",false); json.put("message","Error: "+e.getMessage()); res.setStatus(500); }
        out.print(json.toJSONString());
    }
}
