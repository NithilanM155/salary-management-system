package com.salary.servlet;
import com.salary.dao.SalarySlipDAO;
import com.salary.model.SalarySlip;
import org.json.simple.*;
import org.json.simple.parser.JSONParser;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.*;
import java.util.List;
public class SalarySlipServlet extends HttpServlet {
    private SalarySlipDAO dao = new SalarySlipDAO();
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("application/json"); PrintWriter out = res.getWriter(); JSONObject json = new JSONObject();
        HttpSession session = req.getSession(false);
        if (session==null){json.put("success",false);json.put("message","Unauthorized");res.setStatus(401);out.print(json.toJSONString());return;}
        int uid=(int)session.getAttribute("userId");
        List<SalarySlip> slips = dao.findByUserId(uid);
        JSONArray arr = new JSONArray();
        for (SalarySlip s : slips) { JSONObject o=new JSONObject(); o.put("slipId",s.getSlipId()); o.put("month",s.getMonth()); o.put("year",s.getYear()); o.put("workingHours",s.getWorkingHours()); o.put("salaryPerHour",s.getSalaryPerHour()); o.put("basicSalary",s.getBasicSalary()); o.put("allowances",s.getAllowances()); o.put("deductions",s.getDeductions()); o.put("grossSalary",s.getGrossSalary()); o.put("taxPercentage",s.getTaxPercentage()); o.put("taxAmount",s.getTaxAmount()); o.put("netSalary",s.getNetSalary()); o.put("status",s.getStatus()); arr.add(o); }
        json.put("success",true); json.put("slips",arr); out.print(json.toJSONString());
    }
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("application/json"); PrintWriter out = res.getWriter(); JSONObject json = new JSONObject();
        HttpSession session = req.getSession(false);
        if (session==null){json.put("success",false);json.put("message","Unauthorized");res.setStatus(401);out.print(json.toJSONString());return;}
        try {
            StringBuilder sb=new StringBuilder(); BufferedReader r=req.getReader(); String line; while((line=r.readLine())!=null)sb.append(line);
            JSONObject body=(JSONObject)new JSONParser().parse(sb.toString());
            double wh=Double.parseDouble(body.get("workingHours").toString()); double sph=Double.parseDouble(body.get("salaryPerHour").toString());
            double allow=body.containsKey("allowances")?Double.parseDouble(body.get("allowances").toString()):0;
            double ded=body.containsKey("deductions")?Double.parseDouble(body.get("deductions").toString()):0;
            double taxPct=body.containsKey("taxPercentage")?Double.parseDouble(body.get("taxPercentage").toString()):0;
            int month=Integer.parseInt(body.get("month").toString()); int year=Integer.parseInt(body.get("year").toString());
            double basic=wh*sph; double gross=basic+allow; double tax=gross*taxPct/100; double net=gross-tax-ded;
            SalarySlip s=new SalarySlip(); int uid=(int)session.getAttribute("userId"); s.setUserId(uid); s.setEmployeeId(uid); s.setMonth(month); s.setYear(year); s.setWorkingHours(wh); s.setSalaryPerHour(sph); s.setBasicSalary(basic); s.setAllowances(allow); s.setDeductions(ded); s.setGrossSalary(gross); s.setTaxPercentage(taxPct); s.setTaxAmount(tax); s.setNetSalary(net); s.setStatus("finalized");
            boolean saved=dao.create(s); json.put("success",saved); json.put("message",saved?"Saved":"Failed");
        } catch (Exception e){json.put("success",false);json.put("message",e.getMessage());res.setStatus(500);}
        out.print(json.toJSONString());
    }
}
