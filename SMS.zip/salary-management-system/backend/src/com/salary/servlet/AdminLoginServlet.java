package com.salary.servlet;
import com.salary.dao.UserDAO;
import com.salary.model.User;
import com.salary.util.PasswordUtil;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.*;
public class AdminLoginServlet extends HttpServlet {
    private UserDAO userDAO = new UserDAO();
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("application/json"); PrintWriter out = res.getWriter(); JSONObject json = new JSONObject();
        try {
            StringBuilder sb = new StringBuilder(); BufferedReader reader = req.getReader(); String line;
            while ((line = reader.readLine()) != null) sb.append(line);
            JSONObject body = (JSONObject) new JSONParser().parse(sb.toString());
            String email=(String)body.get("email"); String password=(String)body.get("password");
            User user = userDAO.findByEmail(email);
            if (user==null||!"admin".equals(user.getRole())||!PasswordUtil.verifyPassword(password,user.getPassword())) { json.put("success",false); json.put("message","Invalid admin credentials"); res.setStatus(401); out.print(json.toJSONString()); return; }
            HttpSession session = req.getSession(true); session.setAttribute("userId",user.getUserId()); session.setAttribute("userRole","admin");
            JSONObject ud = new JSONObject(); ud.put("id",user.getUserId()); ud.put("name",user.getName()); ud.put("email",user.getEmail()); ud.put("role","admin"); ud.put("token",session.getId());
            json.put("success",true); json.put("user",ud);
        } catch (Exception e) { json.put("success",false); json.put("message","Error: "+e.getMessage()); res.setStatus(500); }
        out.print(json.toJSONString());
    }
}
