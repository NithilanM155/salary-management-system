package com.salary.servlet;

import com.salary.dao.UserDAO;
import com.salary.model.User;
import com.salary.util.PasswordUtil;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

public class LoginServlet extends HttpServlet {
    private UserDAO userDAO = new UserDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("application/json");
        res.setCharacterEncoding("UTF-8");
        PrintWriter out = res.getWriter();
        JSONObject json = new JSONObject();
        try {
            StringBuilder sb = new StringBuilder();
            BufferedReader reader = req.getReader();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
            JSONParser parser = new JSONParser();
            JSONObject body = (JSONObject) parser.parse(sb.toString());
            String email = (String) body.get("email");
            String password = (String) body.get("password");
            if (email == null || password == null) {
                json.put("success", false); json.put("message", "Email and password required");
                res.setStatus(400); out.print(json.toJSONString()); return;
            }
            User user = userDAO.findByEmail(email);
            if (user == null || !PasswordUtil.verifyPassword(password, user.getPassword())) {
                json.put("success", false); json.put("message", "Invalid email or password");
                res.setStatus(401); out.print(json.toJSONString()); return;
            }
            HttpSession session = req.getSession(true);
            session.setAttribute("userId", user.getUserId());
            session.setAttribute("userEmail", user.getEmail());
            session.setAttribute("userRole", user.getRole());
            JSONObject userData = new JSONObject();
            userData.put("id", user.getUserId()); userData.put("name", user.getName());
            userData.put("email", user.getEmail()); userData.put("role", user.getRole());
            userData.put("token", session.getId());
            json.put("success", true); json.put("message", "Login successful"); json.put("user", userData);
        } catch (Exception e) {
            json.put("success", false); json.put("message", "Server error: " + e.getMessage());
            res.setStatus(500);
        }
        out.print(json.toJSONString());
    }
}
