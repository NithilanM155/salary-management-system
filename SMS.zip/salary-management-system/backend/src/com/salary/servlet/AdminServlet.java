package com.salary.servlet;
import com.salary.dao.SalarySlipDAO;
import com.salary.model.SalarySlip;
import org.json.simple.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.*;
import java.util.List;
public class AdminServlet extends HttpServlet {
    private SalarySlipDAO dao = new SalarySlipDAO();
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session==null||!"admin".equals(session.getAttribute("userRole"))) { res.setContentType("application/json"); res.setStatus(403); res.getWriter().print("{\"success\":false,\"message\":\"Forbidden\"}"); return; }
        String path = req.getPathInfo();
        if ("/generate-tax-file".equals(path)||"/generate-bank-file".equals(path)) {
            res.setContentType("text/csv"); String fname="/generate-tax-file".equals(path)?"tax_records.csv":"bank_transfers.csv"; res.setHeader("Content-Disposition","attachment; filename="+fname);
            List<SalarySlip> slips=dao.findAll(); StringBuilder csv=new StringBuilder("Employee,Month,Year,Gross,Tax%,Tax Amount\n");
            for(SalarySlip s:slips) csv.append(s.getEmployeeName()==null?"Unknown":s.getEmployeeName()).append(",").append(s.getMonth()).append(",").append(s.getYear()).append(",").append(s.getGrossSalary()).append(",").append(s.getTaxPercentage()).append(",").append(s.getTaxAmount()).append("\n");
            res.getWriter().print(csv.toString()); return;
        }
        res.setContentType("application/json"); JSONObject json=new JSONObject();
        List<SalarySlip> slips=dao.findAll(); JSONArray arr=new JSONArray();
        for(SalarySlip s:slips){JSONObject o=new JSONObject();o.put("slipId",s.getSlipId());o.put("employeeName",s.getEmployeeName());o.put("month",s.getMonth());o.put("year",s.getYear());o.put("grossSalary",s.getGrossSalary());o.put("taxAmount",s.getTaxAmount());o.put("netSalary",s.getNetSalary());arr.add(o);}
        json.put("success",true); json.put("slips",arr); res.getWriter().print(json.toJSONString());
    }
}
