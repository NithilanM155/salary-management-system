package com.salary.dao;
import com.salary.model.User;
import com.salary.util.DatabaseConnection;
import java.sql.*;
public class UserDAO {
    public User findByEmail(String email) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM users WHERE email = ?")) {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) { User u = new User(); u.setUserId(rs.getInt("user_id")); u.setEmail(rs.getString("email")); u.setPassword(rs.getString("password")); u.setName(rs.getString("name")); u.setRole(rs.getString("role")); return u; }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }
    public boolean create(User user) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO users (email, password, name, role) VALUES (?,?,?,?)")) {
            ps.setString(1, user.getEmail()); ps.setString(2, user.getPassword()); ps.setString(3, user.getName()); ps.setString(4, user.getRole());
            return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }
}
