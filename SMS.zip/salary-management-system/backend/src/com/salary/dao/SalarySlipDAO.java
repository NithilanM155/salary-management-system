package com.salary.dao;
import com.salary.model.SalarySlip;
import com.salary.util.DatabaseConnection;
import java.sql.*;
import java.util.*;
public class SalarySlipDAO {
    public boolean create(SalarySlip s) {
        String sql = "INSERT INTO salary_slips (employee_id,user_id,month,year,working_hours,salary_per_hour,basic_salary,allowances,deductions,gross_salary,tax_percentage,tax_amount,net_salary,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try (Connection c = DatabaseConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1,s.getEmployeeId()); ps.setInt(2,s.getUserId()); ps.setInt(3,s.getMonth()); ps.setInt(4,s.getYear()); ps.setDouble(5,s.getWorkingHours()); ps.setDouble(6,s.getSalaryPerHour()); ps.setDouble(7,s.getBasicSalary()); ps.setDouble(8,s.getAllowances()); ps.setDouble(9,s.getDeductions()); ps.setDouble(10,s.getGrossSalary()); ps.setDouble(11,s.getTaxPercentage()); ps.setDouble(12,s.getTaxAmount()); ps.setDouble(13,s.getNetSalary()); ps.setString(14,s.getStatus());
            return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); } return false;
    }
    public List<SalarySlip> findByUserId(int userId) {
        List<SalarySlip> list = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection(); PreparedStatement ps = c.prepareStatement("SELECT * FROM salary_slips WHERE user_id=? ORDER BY year DESC, month DESC")) {
            ps.setInt(1, userId); ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (Exception e) { e.printStackTrace(); } return list;
    }
    public List<SalarySlip> findAll() {
        List<SalarySlip> list = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection(); Statement st = c.createStatement()) {
            ResultSet rs = st.executeQuery("SELECT ss.*,u.name as emp_name FROM salary_slips ss JOIN users u ON ss.user_id=u.user_id ORDER BY ss.year DESC,ss.month DESC");
            while (rs.next()) { SalarySlip s = map(rs); try{s.setEmployeeName(rs.getString("emp_name"));}catch(Exception ex){} list.add(s); }
        } catch (Exception e) { e.printStackTrace(); } return list;
    }
    public boolean update(SalarySlip s) {
        try (Connection c = DatabaseConnection.getConnection(); PreparedStatement ps = c.prepareStatement("UPDATE salary_slips SET working_hours=?,salary_per_hour=?,basic_salary=?,allowances=?,deductions=?,gross_salary=?,tax_percentage=?,tax_amount=?,net_salary=? WHERE slip_id=?")) {
            ps.setDouble(1,s.getWorkingHours()); ps.setDouble(2,s.getSalaryPerHour()); ps.setDouble(3,s.getBasicSalary()); ps.setDouble(4,s.getAllowances()); ps.setDouble(5,s.getDeductions()); ps.setDouble(6,s.getGrossSalary()); ps.setDouble(7,s.getTaxPercentage()); ps.setDouble(8,s.getTaxAmount()); ps.setDouble(9,s.getNetSalary()); ps.setInt(10,s.getSlipId());
            return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); } return false;
    }
    private SalarySlip map(ResultSet rs) throws SQLException {
        SalarySlip s = new SalarySlip(); s.setSlipId(rs.getInt("slip_id")); s.setEmployeeId(rs.getInt("employee_id")); s.setUserId(rs.getInt("user_id")); s.setMonth(rs.getInt("month")); s.setYear(rs.getInt("year")); s.setWorkingHours(rs.getDouble("working_hours")); s.setSalaryPerHour(rs.getDouble("salary_per_hour")); s.setBasicSalary(rs.getDouble("basic_salary")); s.setAllowances(rs.getDouble("allowances")); s.setDeductions(rs.getDouble("deductions")); s.setGrossSalary(rs.getDouble("gross_salary")); s.setTaxPercentage(rs.getDouble("tax_percentage")); s.setTaxAmount(rs.getDouble("tax_amount")); s.setNetSalary(rs.getDouble("net_salary")); s.setStatus(rs.getString("status")); return s;
    }
}
