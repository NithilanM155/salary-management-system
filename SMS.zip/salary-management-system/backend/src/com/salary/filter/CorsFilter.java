package com.salary.filter;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
public class CorsFilter implements Filter {
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        HttpServletResponse r = (HttpServletResponse) res;
        r.setHeader("Access-Control-Allow-Origin","*");
        r.setHeader("Access-Control-Allow-Methods","GET,POST,PUT,DELETE,OPTIONS");
        r.setHeader("Access-Control-Allow-Headers","Content-Type,Authorization");
        if ("OPTIONS".equalsIgnoreCase(((HttpServletRequest)req).getMethod())) { r.setStatus(200); return; }
        chain.doFilter(req, res);
    }
    public void init(FilterConfig fc) {} public void destroy() {}
}
