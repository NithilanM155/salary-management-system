package com.salary.filter;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
public class AuthenticationFilter implements Filter {
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) { chain.doFilter(req,res); return; }
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            HttpServletResponse response = (HttpServletResponse) res;
            response.setContentType("application/json"); response.setStatus(401);
            response.getWriter().print("{\"success\":false,\"message\":\"Please login\"}"); return;
        }
        chain.doFilter(req, res);
    }
    public void init(FilterConfig fc) {} public void destroy() {}
}
