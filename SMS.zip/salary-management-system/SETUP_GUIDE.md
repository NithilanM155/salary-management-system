# Salary Management System - Complete Setup Guide

## Project Overview
A professional salary management system with HTML/CSS/JavaScript frontend and Java/MySQL backend. Features include employee salary calculation, tax management, salary slip generation, and admin controls.

## Technology Stack
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Backend**: Java 8+, Servlets
- **Database**: MySQL 5.7+
- **Libraries**: iText (PDF), json-simple

## Prerequisites
1. JDK 8 or higher
2. MySQL 5.7+
3. Apache Tomcat 8.5+
4. VS Code or any IDE
5. MySQL Workbench (optional, for database management)

## Installation Steps

### 1. Database Setup
```sql
-- Execute the database/salary_management.sql file
mysql -u root -p < database/salary_management.sql

-- Or manually:
CREATE DATABASE salary_management_db;
USE salary_management_db;
-- Then copy all SQL from salary_management.sql and execute
```

### 2. Backend Setup

#### Step 1: Download Required Libraries
```
backend/lib/
├── mysql-connector-java-8.0.33.jar
├── itext-7.2.1.jar
└── json-simple-1.1.1.jar
```

#### Step 2: Create Java Project Structure
```
backend/
├── src/
│   └── com/salary/
│       ├── servlet/
│       ├── controller/
│       ├── model/
│       ├── dao/
│       ├── service/
│       └── util/
└── web/WEB-INF/web.xml
```

#### Step 3: Compile Java Files
```bash
cd backend
javac -cp "lib/*" src/com/salary/**/*.java -d bin/
```

#### Step 4: Create WAR File
```bash
jar cvf salary-management.war -C bin/ .
```

#### Step 5: Deploy to Tomcat
```bash
cp salary-management.war /path/to/tomcat/webapps/
```

### 3. Frontend Setup

1. Copy all frontend files to:
   ```
   /var/www/html/salary-management/ (Linux/Mac)
   C:\xampp\htdocs\salary-management\ (Windows with XAMPP)
   ```

2. Update API URL in `frontend/js/auth.js` and `frontend/js/api.js`:
   ```javascript
   this.apiUrl = 'http://localhost:8080/salary-management';
   ```

3. Start a local server:
   ```bash
   # Using Python
   python -m http.server 3000
   
   # Using Node.js
   npx http-server -p 3000
   
   # Or use Live Server extension in VS Code
   ```

## Folder Structure

```
salary-management-system/
│
├── frontend/
│   ├── index.html                 # Login/Register page
│   ├── css/
│   │   ├── style.css              # Main styles
│   │   ├── login.css              # Login page styles
│   │   ├── dashboard.css          # Dashboard styles
│   │   └── responsive.css         # Mobile responsive
│   ├── js/
│   │   ├── auth.js                # Authentication
│   │   ├── api.js                 # API calls
│   │   ├── dashboard.js           # Dashboard logic
│   │   ├── salary-calculator.js   # Calculations
│   │   └── charts.js              # Chart rendering
│   ├── pages/
│   │   ├── dashboard.html         # Employee dashboard
│   │   ├── salary-slip.html       # Salary slip form
│   │   └── admin-panel.html       # Admin dashboard
│   └── assets/images/
│
├── backend/
│   ├── src/com/salary/
│   │   ├── servlet/
│   │   │   ├── LoginServlet.java
│   │   │   ├── RegisterServlet.java
│   │   │   ├── SalarySlipServlet.java
│   │   │   ├── DownloadServlet.java
│   │   │   ├── AdminServlet.java
│   │   │   └── ReportServlet.java
│   │   ├── controller/
│   │   │   ├── AuthController.java
│   │   │   ├── SalaryController.java
│   │   │   ├── TaxController.java
│   │   │   └── AdminController.java
│   │   ├── model/
│   │   │   ├── User.java
│   │   │   ├── Employee.java
│   │   │   ├── SalarySlip.java
│   │   │   ├── TaxRecord.java
│   │   │   └── Response.java
│   │   ├── dao/
│   │   │   ├── UserDAO.java
│   │   │   ├── EmployeeDAO.java
│   │   │   ├── SalarySlipDAO.java
│   │   │   ├── TaxDAO.java
│   │   │   └── BaseDAO.java
│   │   ├── service/
│   │   │   ├── AuthService.java
│   │   │   ├── SalaryService.java
│   │   │   ├── TaxService.java
│   │   │   ├── PDFService.java
│   │   │   ├── ExcelService.java
│   │   │   └── MailService.java
│   │   └── util/
│   │       ├── DatabaseConnection.java
│   │       ├── PasswordUtil.java
│   │       ├── ValidationUtil.java
│   │       ├── DateUtil.java
│   │       └── FileUtil.java
│   ├── lib/
│   │   ├── mysql-connector-java-8.0.33.jar
│   │   ├── itext-7.2.1.jar
│   │   └── json-simple-1.1.1.jar
│   └── web/WEB-INF/web.xml
│
├── database/
│   └── salary_management.sql
│
├── documentation/
│   ├── API_DOCUMENTATION.md
│   ├── DATABASE_SCHEMA.md
│   └── USER_GUIDE.md
│
├── SETUP_GUIDE.md
└── README.md
```

## Default Credentials

### Admin Login
- Email: `admin@salary.com`
- Password: `admin123`

### Demo Employee (After Registration)
- Create new account with any email and password
- Login and proceed to create salary slip

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `POST /api/auth/admin-login` - Admin login
- `POST /api/auth/logout` - Logout

### Employee Endpoints
- `GET /api/employee/profile` - Get employee profile
- `POST /api/salary/create-slip` - Create salary slip
- `GET /api/salary/slips` - Get all salary slips
- `GET /api/salary/slip/{id}` - Get specific salary slip
- `PUT /api/salary/slip/{id}` - Update salary slip
- `GET /api/salary/slip/{id}/download` - Download PDF

### Admin Endpoints
- `GET /api/admin/dashboard` - Get dashboard data
- `GET /api/admin/employees` - Get all employees
- `POST /api/admin/employee` - Create employee
- `PUT /api/admin/employee/{id}` - Update employee
- `DELETE /api/admin/employee/{id}` - Delete employee
- `GET /api/admin/salary-slips` - Get all salary slips
- `GET /api/admin/generate-tax-file` - Download tax file
- `GET /api/admin/generate-bank-file` - Download bank file

## Features Implemented

### 1. User Management
✓ Registration with email and password
✓ Secure login with session management
✓ Admin panel access
✓ User profile management
✓ Password reset functionality

### 2. Salary Management
✓ Create salary slips with calculations
✓ Monthly and annual salary calculation
✓ Automatic tax deduction
✓ Allowances and deductions management
✓ Salary slip PDF generation
✓ Edit salary slip data
✓ Download salary slip

### 3. Tax Management
✓ Automatic tax calculation
✓ Tax percentage configuration
✓ Monthly tax records
✓ Annual tax summary
✓ Tax file generation (CSV)
✓ Tax report generation

### 4. Reports & Analytics
✓ Monthly salary charts (Pie chart)
✓ Annual salary charts
✓ Tax breakdown visualization
✓ Employee salary comparison
✓ Salary trends analysis

### 5. File Generation
✓ PDF salary slip generation
✓ CSV bank transfer file
✓ CSV tax file
✓ Excel salary report

### 6. Admin Features
✓ Employee management
✓ Salary monitoring
✓ Tax management
✓ System settings
✓ Organization configuration
✓ Report generation

## Configuration Files

### database/salary_management.sql
Contains complete database schema with all tables, indexes, and sample data.

### backend/web.xml
Servlet mapping and configuration:
```xml
<servlet>
    <servlet-name>LoginServlet</servlet-name>
    <servlet-class>com.salary.servlet.LoginServlet</servlet-class>
</servlet>
```

### Database Connection (Java)
```java
String dbUrl = "jdbc:mysql://localhost:3306/salary_management_db";
String user = "root";
String password = "your_password";
```

## Environment Variables
Create a `.env` file in the project root:
```
DB_URL=jdbc:mysql://localhost:3306/salary_management_db
DB_USER=root
DB_PASSWORD=your_password
TOMCAT_PATH=/path/to/tomcat
APP_URL=http://localhost:8080/salary-management
```

## Running the Application

### 1. Start MySQL Server
```bash
# Windows
net start MySQL80

# Linux/Mac
sudo systemctl start mysql

# Or use XAMPP/WAMP panel
```

### 2. Start Tomcat Server
```bash
# Windows
catalina.bat run

# Linux/Mac
./catalina.sh run
```

### 3. Start Frontend Development Server
```bash
# Navigate to frontend folder
cd frontend

# Using Live Server in VS Code
# Or use Python: python -m http.server 3000
```

### 4. Access Application
- Frontend: `http://localhost:3000`
- Backend API: `http://localhost:8080/salary-management`

## Troubleshooting

### Issue: "Cannot connect to database"
- Check MySQL is running
- Verify database credentials
- Ensure salary_management_db exists

### Issue: "404 - Servlet not found"
- Check Tomcat is running
- Verify WAR file is deployed
- Check web.xml configuration

### Issue: "CORS error"
- Add CORS headers in servlets
- Configure web.xml for CORS
- Check API URL in JavaScript

### Issue: "PDF generation fails"
- Verify iText JAR is in lib folder
- Check file permissions
- Ensure temp folder exists

## Performance Optimization

### Database
- Use indexes on frequently queried columns
- Implement connection pooling
- Cache frequently accessed data

### Frontend
- Minify CSS and JavaScript
- Implement lazy loading for charts
- Use local storage for session data

### Backend
- Implement caching mechanism
- Use prepared statements
- Optimize database queries

## Security Considerations

1. **Authentication**
   - Use bcrypt for password hashing
   - Implement JWT tokens
   - Session timeout after 30 minutes

2. **Authorization**
   - Role-based access control
   - Verify user permissions
   - Protect sensitive endpoints

3. **Data Protection**
   - Use HTTPS in production
   - Implement CSRF protection
   - Sanitize user inputs
   - Use prepared statements

4. **Audit Trail**
   - Log all operations
   - Track user actions
   - Monitor failed login attempts

## Backup & Recovery

### Database Backup
```bash
mysqldump -u root -p salary_management_db > backup.sql
```

### Database Restore
```bash
mysql -u root -p salary_management_db < backup.sql
```

## Support & Documentation

For detailed documentation, refer to:
- `API_DOCUMENTATION.md` - Complete API reference
- `DATABASE_SCHEMA.md` - Database design details
- `USER_GUIDE.md` - User manual

## Future Enhancements

- [ ] Multi-language support
- [ ] Mobile app (iOS/Android)
- [ ] Advanced reporting with graphs
- [ ] Email notifications
- [ ] Biometric attendance integration
- [ ] Leave management system
- [ ] Performance appraisal module
- [ ] Payroll automation

## License
This project is provided for educational purposes.

## Support
For issues or questions, contact the development team.

---
Last Updated: 2024
Version: 1.0.0
