// ====================================
// AUTH MODULE — localStorage (no backend)
// ====================================

document.addEventListener('DOMContentLoaded', () => {
    const u = localStorage.getItem('sms_user') || sessionStorage.getItem('sms_user');
    if (u) {
        const user = JSON.parse(u);
        window.location.href = user.role === 'admin' ? 'pages/admin-panel.html' : 'pages/dashboard.html';
        return;
    }
    document.getElementById('loginFormElement').addEventListener('submit', handleLogin);
    document.getElementById('registerFormElement').addEventListener('submit', handleRegister);
    document.getElementById('adminLoginForm').addEventListener('submit', handleAdminLogin);
});

function toggleForms() {
    document.getElementById('loginForm').classList.toggle('hidden');
    document.getElementById('registerForm').classList.toggle('hidden');
    document.querySelectorAll('.form-error').forEach(el => el.textContent = '');
}

function openAdminModal() { document.getElementById('adminModal').classList.remove('hidden'); }
function closeAdminModal() { document.getElementById('adminModal').classList.add('hidden'); }
window.addEventListener('click', e => { if (e.target === document.getElementById('adminModal')) closeAdminModal(); });

function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;
    const remember = document.getElementById('rememberMe').checked;
    clearErrors();
    if (!isValidEmail(email)) { showFieldError('loginEmailError', 'Enter a valid email'); return; }
    if (!password) { showFieldError('loginPasswordError', 'Enter your password'); return; }
    const users = getAllUsers();
    const user = users.find(u => u.email === email && u.password === password);
    if (!user) { showToast('Invalid email or password', 'error'); return; }
    saveSession(user, remember);
    showToast('Login successful! Redirecting...', 'success');
    setTimeout(() => { window.location.href = user.role === 'admin' ? 'pages/admin-panel.html' : 'pages/dashboard.html'; }, 800);
}

function handleRegister(e) {
    e.preventDefault();
    const name = document.getElementById('fullName').value.trim();
    const email = document.getElementById('registerEmail').value.trim();
    const password = document.getElementById('registerPassword').value;
    const confirm = document.getElementById('confirmPassword').value;
    const agree = document.getElementById('agreeTerms').checked;
    clearErrors();
    if (name.length < 2) { showFieldError('nameError', 'Name must be at least 2 characters'); return; }
    if (!isValidEmail(email)) { showFieldError('registerEmailError', 'Enter a valid email'); return; }
    if (password.length < 6) { showFieldError('registerPasswordError', 'Password must be at least 6 characters'); return; }
    if (password !== confirm) { showFieldError('confirmPasswordError', 'Passwords do not match'); return; }
    if (!agree) { showFieldError('termsError', 'You must agree to the terms'); return; }
    const users = getAllUsers();
    if (users.find(u => u.email === email)) { showFieldError('registerEmailError', 'Email already registered'); return; }
    const newUser = { name, email, password, role: 'employee', designation: '', department: '', phone: '', salaryPerHour: 0, createdAt: new Date().toISOString() };
    users.push(newUser);
    saveAllUsers(users);
    showToast('Account created! Please login.', 'success');
    setTimeout(() => { toggleForms(); document.getElementById('registerFormElement').reset(); }, 1000);
}

function handleAdminLogin(e) {
    e.preventDefault();
    const email = document.getElementById('adminEmail').value.trim();
    const password = document.getElementById('adminPassword').value;
    if (!isValidEmail(email)) { showFieldError('adminEmailError', 'Enter a valid email'); return; }
    if (!password) { showFieldError('adminPasswordError', 'Enter password'); return; }
    const adminPw = JSON.parse(localStorage.getItem('sms_admin_password') || '"admin123"');
    if (email === 'admin@salary.com' && password === adminPw) {
        const adminUser = { name: 'System Admin', email: 'admin@salary.com', role: 'admin' };
        saveSession(adminUser, false);
        closeAdminModal();
        showToast('Admin login successful!', 'success');
        setTimeout(() => window.location.href = 'pages/admin-panel.html', 800);
        return;
    }
    showToast('Invalid admin credentials', 'error');
}

function getAllUsers() { const d = localStorage.getItem('sms_all_users'); return d ? JSON.parse(d) : []; }
function saveAllUsers(u) { localStorage.setItem('sms_all_users', JSON.stringify(u)); }
function saveSession(user, remember) {
    const safe = { name: user.name, email: user.email, role: user.role, designation: user.designation||'', department: user.department||'', phone: user.phone||'', salaryPerHour: user.salaryPerHour||0 };
    const json = JSON.stringify(safe);
    if (remember) localStorage.setItem('sms_user', json); else sessionStorage.setItem('sms_user', json);
}
function isValidEmail(email) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email); }
function showFieldError(id, msg) { const el = document.getElementById(id); if (el) el.textContent = msg; }
function clearErrors() { document.querySelectorAll('.form-error').forEach(el => el.textContent = ''); }
function showToast(msg, type = 'info') {
    const t = document.getElementById('toast');
    if (!t) return;
    t.textContent = msg; t.className = `toast ${type}`; t.classList.remove('hidden');
    setTimeout(() => t.classList.add('hidden'), 3000);
}
