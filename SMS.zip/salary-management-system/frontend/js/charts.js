// charts.js — Chart rendering helpers (Chart.js loaded via CDN)
// Charts are rendered inline in dashboard.js and admin.js using Chart.js
