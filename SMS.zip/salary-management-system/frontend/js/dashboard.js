// ====================================
// DASHBOARD MODULE
// Works with localStorage (no backend required)
// ====================================

const MONTHS = ['','January','February','March','April','May','June',
                'July','August','September','October','November','December'];

let currentSlips = [];
let editingSlipId = null;
let viewingSlipId = null;

// ---- INIT ----
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    loadUser();
    loadSlips();
    document.getElementById('currentDate').textContent = new Date().toLocaleDateString('en-IN',{weekday:'long',year:'numeric',month:'long',day:'numeric'});
    document.getElementById('slipYear').value = new Date().getFullYear();
    document.getElementById('slipMonth').value = new Date().getMonth() + 1;

    // Salary slip form
    document.getElementById('salarySlipForm').addEventListener('submit', saveSlip);
    // Profile form
    document.getElementById('profileForm').addEventListener('submit', saveProfile);
    // Edit form
    document.getElementById('editSlipForm').addEventListener('submit', updateSlip);

    showSection('overview');
    populateYearFilter();
});

function checkAuth() {
    const user = getUser();
    if (!user) {
        window.location.href = '../index.html';
    }
}

function getUser() {
    const u = localStorage.getItem('sms_user') || sessionStorage.getItem('sms_user');
    return u ? JSON.parse(u) : null;
}

function loadUser() {
    const user = getUser();
    if (!user) return;
    document.getElementById('sidebarUserName').textContent = user.name || 'Employee';
    document.getElementById('sidebarUserEmail').textContent = user.email || '';
    document.getElementById('avatarInitial').textContent = (user.name || 'U')[0].toUpperCase();
    document.getElementById('profileName').value = user.name || '';
    document.getElementById('profileEmail').value = user.email || '';
    document.getElementById('profileDesignation').value = user.designation || '';
    document.getElementById('profileDepartment').value = user.department || '';
    document.getElementById('profilePhone').value = user.phone || '';
    document.getElementById('profileSalaryPerHour').value = user.salaryPerHour || '';
    // Pre-fill slip form
    document.getElementById('empName').value = user.name || '';
    if (user.salaryPerHour) document.getElementById('salaryPerHour').value = user.salaryPerHour;
    if (user.designation) document.getElementById('empDesignation').value = user.designation;
}

// ---- SECTIONS ----
function showSection(name) {
    document.querySelectorAll('.content > section').forEach(s => s.classList.add('hidden'));
    document.getElementById(`section-${name}`).classList.remove('hidden');
    document.getElementById('pageTitle').textContent = {
        'overview': 'Dashboard',
        'salary-slip': 'Create Salary Slip',
        'history': 'Slip History',
        'tax': 'Tax Records',
        'reports': 'Reports',
        'profile': 'My Profile'
    }[name] || name;
    document.querySelectorAll('.sidebar-nav a').forEach(a => a.classList.remove('active'));
    const idx = ['overview','salary-slip','history','tax','reports','profile'].indexOf(name);
    const links = document.querySelectorAll('.sidebar-nav a');
    if (links[idx]) links[idx].classList.add('active');

    if (name === 'overview') renderOverview();
    if (name === 'history') renderHistoryTable(currentSlips);
    if (name === 'tax') renderTaxSection();
    if (name === 'reports') renderReports();
}

// ---- LOAD SLIPS ----
function loadSlips() {
    const user = getUser();
    if (!user) return;
    const key = `sms_slips_${user.email}`;
    const data = localStorage.getItem(key);
    currentSlips = data ? JSON.parse(data) : [];
    renderOverview();
    populateYearFilter();
}

function saveSlipsToStorage() {
    const user = getUser();
    if (!user) return;
    localStorage.setItem(`sms_slips_${user.email}`, JSON.stringify(currentSlips));
}

// ---- SAVE SLIP ----
function saveSlip(e) {
    e.preventDefault();
    const user = getUser();
    const wh = parseFloat(document.getElementById('workingHours').value) || 0;
    const sph = parseFloat(document.getElementById('salaryPerHour').value) || 0;
    const allowances = parseFloat(document.getElementById('allowances').value) || 0;
    const deductions = parseFloat(document.getElementById('deductions').value) || 0;
    const taxPct = parseFloat(document.getElementById('taxPercentage').value) || 0;
    const month = parseInt(document.getElementById('slipMonth').value);
    const year = parseInt(document.getElementById('slipYear').value);

    if (!wh || !sph || !month || !year) {
        showToast('Please fill all required fields!', 'error');
        return;
    }

    const calc = salaryCalculator.calculateSalarySlip({workingHours:wh, salaryPerHour:sph, allowances, deductions, taxPercentage:taxPct});

    const slip = {
        id: Date.now(),
        empName: document.getElementById('empName').value,
        empId: document.getElementById('empId').value,
        designation: document.getElementById('empDesignation').value,
        department: document.getElementById('empDepartment').value,
        month, year, workingHours: wh, salaryPerHour: sph,
        allowances, deductions, taxPercentage: taxPct,
        ...calc,
        status: 'finalized',
        createdAt: new Date().toISOString()
    };

    currentSlips.unshift(slip);
    saveSlipsToStorage();
    showToast('Salary slip saved successfully!', 'success');
    resetSlipForm();
    showSection('overview');
}

// ---- RECALCULATE PREVIEW ----
function recalculate() {
    const wh = parseFloat(document.getElementById('workingHours').value) || 0;
    const sph = parseFloat(document.getElementById('salaryPerHour').value) || 0;
    const allowances = parseFloat(document.getElementById('allowances').value) || 0;
    const deductions = parseFloat(document.getElementById('deductions').value) || 0;
    const taxPct = parseFloat(document.getElementById('taxPercentage').value) || 0;

    if (wh > 0 && sph > 0) {
        const calc = salaryCalculator.calculateSalarySlip({workingHours:wh, salaryPerHour:sph, allowances, deductions, taxPercentage:taxPct});
        document.getElementById('previewBasic').textContent = fmt(calc.basicSalary);
        document.getElementById('previewGross').textContent = fmt(calc.grossSalary);
        document.getElementById('previewTax').textContent = fmt(calc.taxAmount);
        document.getElementById('previewNet').textContent = fmt(calc.netSalary);
        document.getElementById('salaryPreview').style.display = 'block';
    } else {
        document.getElementById('salaryPreview').style.display = 'none';
    }
}

function recalculateEdit() {
    const wh = parseFloat(document.getElementById('editWorkingHours').value) || 0;
    const sph = parseFloat(document.getElementById('editSalaryPerHour').value) || 0;
    const allowances = parseFloat(document.getElementById('editAllowances').value) || 0;
    const deductions = parseFloat(document.getElementById('editDeductions').value) || 0;
    const taxPct = parseFloat(document.getElementById('editTaxPercentage').value) || 0;
    if (wh > 0 && sph > 0) {
        const calc = salaryCalculator.calculateSalarySlip({workingHours:wh, salaryPerHour:sph, allowances, deductions, taxPercentage:taxPct});
        document.getElementById('editPreviewNet').textContent = fmt(calc.netSalary);
        document.getElementById('editPreviewTax').textContent = fmt(calc.taxAmount);
    }
}

function resetSlipForm() {
    document.getElementById('salarySlipForm').reset();
    document.getElementById('salaryPreview').style.display = 'none';
    document.getElementById('slipYear').value = new Date().getFullYear();
    document.getElementById('slipMonth').value = new Date().getMonth() + 1;
    loadUser();
}

// ---- OVERVIEW ----
function renderOverview() {
    const now = new Date();
    const curMonth = now.getMonth() + 1;
    const curYear = now.getFullYear();
    const thisMonthSlips = currentSlips.filter(s => s.month == curMonth && s.year == curYear);
    const thisYearSlips = currentSlips.filter(s => s.year == curYear);

    const monthNet = thisMonthSlips.reduce((a, s) => a + (s.netSalary||0), 0);
    const annualNet = thisYearSlips.reduce((a, s) => a + (s.netSalary||0), 0);
    const annualTax = thisYearSlips.reduce((a, s) => a + (s.taxAmount||0), 0);

    document.getElementById('statMonthlyNet').textContent = fmt(monthNet);
    document.getElementById('statAnnualNet').textContent = fmt(annualNet);
    document.getElementById('statTaxPaid').textContent = fmt(annualTax);
    document.getElementById('statSlipCount').textContent = currentSlips.length;

    renderRecentSlips();
    renderOverviewCharts();
}

function renderRecentSlips() {
    const tbody = document.getElementById('recentSlipsBody');
    const recent = currentSlips.slice(0, 5);
    if (recent.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center" style="padding:2rem;color:#9ca3af;">No salary slips yet. Create one!</td></tr>';
        return;
    }
    tbody.innerHTML = recent.map(s => `
        <tr>
            <td>${MONTHS[s.month]} ${s.year}</td>
            <td>${fmt(s.grossSalary)}</td>
            <td>${fmt(s.taxAmount)}</td>
            <td><strong>${fmt(s.netSalary)}</strong></td>
            <td><span class="badge badge-success">${s.status}</span></td>
            <td>
                <div class="action-buttons">
                    <button class="action-btn download" onclick="viewSlip(${s.id})">👁 View</button>
                    <button class="action-btn edit" onclick="openEditModal(${s.id})">✏ Edit</button>
                    <button class="action-btn download" onclick="downloadSlipPDF(${s.id})">⬇ PDF</button>
                </div>
            </td>
        </tr>`).join('');
}

// ---- HISTORY TABLE ----
function renderHistoryTable(slips) {
    const tbody = document.getElementById('historyTableBody');
    if (slips.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center" style="padding:2rem;color:#9ca3af;">No records found.</td></tr>';
        return;
    }
    tbody.innerHTML = slips.map((s, i) => `
        <tr>
            <td>${i+1}</td>
            <td>${s.empName || 'N/A'}<br><small style="color:#9ca3af;">${s.empId || ''}</small></td>
            <td>${MONTHS[s.month]} ${s.year}</td>
            <td>${s.workingHours}h</td>
            <td>${fmt(s.grossSalary)}</td>
            <td>${fmt(s.taxAmount)}</td>
            <td><strong>${fmt(s.netSalary)}</strong></td>
            <td><span class="badge badge-success">${s.status}</span></td>
            <td>
                <div class="action-buttons">
                    <button class="action-btn download" onclick="viewSlip(${s.id})">👁</button>
                    <button class="action-btn edit" onclick="openEditModal(${s.id})">✏</button>
                    <button class="action-btn download" onclick="downloadSlipPDF(${s.id})">⬇</button>
                    <button class="action-btn delete" onclick="deleteSlip(${s.id})">🗑</button>
                </div>
            </td>
        </tr>`).join('');
}

function filterSlips() {
    const year = document.getElementById('filterYear').value;
    const month = document.getElementById('filterMonth').value;
    let filtered = [...currentSlips];
    if (year) filtered = filtered.filter(s => s.year == year);
    if (month) filtered = filtered.filter(s => s.month == month);
    renderHistoryTable(filtered);
}

function populateYearFilter() {
    const years = [...new Set(currentSlips.map(s => s.year))].sort((a,b)=>b-a);
    const sel = document.getElementById('filterYear');
    if (!sel) return;
    const cur = sel.value;
    sel.innerHTML = '<option value="">All Years</option>' + years.map(y=>`<option value="${y}">${y}</option>`).join('');
    if (cur) sel.value = cur;
}

// ---- TAX SECTION ----
function renderTaxSection() {
    const now = new Date();
    const yearSlips = currentSlips.filter(s => s.year == now.getFullYear());
    const annualTax = yearSlips.reduce((a,s)=>a+(s.taxAmount||0),0);
    const avgTax = yearSlips.length ? annualTax/yearSlips.length : 0;
    const avgPct = yearSlips.length ? yearSlips.reduce((a,s)=>a+(s.taxPercentage||0),0)/yearSlips.length : 0;

    document.getElementById('annualTaxPayable').textContent = fmt(annualTax);
    document.getElementById('avgMonthlyTax').textContent = fmt(avgTax);
    document.getElementById('avgTaxPct').textContent = avgPct.toFixed(1) + '%';

    // Tax table
    const tbody = document.getElementById('taxTableBody');
    if (yearSlips.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center" style="padding:2rem;color:#9ca3af;">No tax records.</td></tr>';
    } else {
        tbody.innerHTML = yearSlips.map(s=>`
            <tr>
                <td>${MONTHS[s.month]} ${s.year}</td>
                <td>${fmt(s.grossSalary)}</td>
                <td>${s.taxPercentage}%</td>
                <td>${fmt(s.taxAmount)}</td>
                <td><span class="badge badge-warning">Paid</span></td>
            </tr>`).join('');
    }

    renderTaxCharts(yearSlips);
}

// ---- REPORTS ----
function renderReports() {
    renderReportCharts();
}

// ---- CHARTS ----
let chartInstances = {};
function destroyChart(id) {
    if (chartInstances[id]) { chartInstances[id].destroy(); delete chartInstances[id]; }
}

function renderOverviewCharts() {
    const now = new Date();
    const curYear = now.getFullYear();
    const yearSlips = currentSlips.filter(s => s.year == curYear);

    // Monthly bar chart
    const monthlyData = Array(12).fill(0).map((_, i) => {
        const m = i + 1;
        const slips = yearSlips.filter(s => s.month == m);
        return slips.reduce((a, s) => a + (s.netSalary||0), 0);
    });

    destroyChart('monthlySalaryChart');
    const ctx1 = document.getElementById('monthlySalaryChart').getContext('2d');
    chartInstances['monthlySalaryChart'] = new Chart(ctx1, {
        type: 'bar',
        data: {
            labels: MONTHS.slice(1),
            datasets: [{
                label: 'Net Salary (₹)',
                data: monthlyData,
                backgroundColor: 'rgba(37,99,235,0.7)',
                borderColor: '#2563eb',
                borderWidth: 2,
                borderRadius: 6
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, ticks: { callback: v => '₹'+v.toLocaleString('en-IN') } } }
        }
    });

    // Pie chart: gross vs tax vs deductions
    const totalGross = yearSlips.reduce((a,s)=>a+(s.basicSalary||0),0);
    const totalAllowances = yearSlips.reduce((a,s)=>a+(s.allowances||0),0);
    const totalTax = yearSlips.reduce((a,s)=>a+(s.taxAmount||0),0);
    const totalDed = yearSlips.reduce((a,s)=>a+(s.deductions||0),0);
    const totalNet = yearSlips.reduce((a,s)=>a+(s.netSalary||0),0);

    destroyChart('annualSalaryChart');
    const ctx2 = document.getElementById('annualSalaryChart').getContext('2d');
    chartInstances['annualSalaryChart'] = new Chart(ctx2, {
        type: 'doughnut',
        data: {
            labels: ['Basic Salary', 'Allowances', 'Tax', 'Other Deductions'],
            datasets: [{
                data: [totalGross, totalAllowances, totalTax, totalDed],
                backgroundColor: ['#2563eb','#10b981','#f59e0b','#ef4444'],
                borderWidth: 3
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { position: 'bottom' } }
        }
    });
}

function renderTaxCharts(slips) {
    // Pie: tax vs net
    const totalTax = slips.reduce((a,s)=>a+(s.taxAmount||0),0);
    const totalNet = slips.reduce((a,s)=>a+(s.netSalary||0),0);

    destroyChart('taxPieChart');
    const ctx1 = document.getElementById('taxPieChart').getContext('2d');
    chartInstances['taxPieChart'] = new Chart(ctx1, {
        type: 'pie',
        data: {
            labels: ['Tax Deducted', 'Take Home'],
            datasets: [{ data: [totalTax, totalNet], backgroundColor: ['#f59e0b','#2563eb'], borderWidth: 3 }]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }
    });

    // Bar: monthly tax
    const monthlyTax = Array(12).fill(0).map((_,i) => {
        const m = i+1;
        return slips.filter(s=>s.month==m).reduce((a,s)=>a+(s.taxAmount||0),0);
    });

    destroyChart('taxBarChart');
    const ctx2 = document.getElementById('taxBarChart').getContext('2d');
    chartInstances['taxBarChart'] = new Chart(ctx2, {
        type: 'bar',
        data: {
            labels: MONTHS.slice(1),
            datasets: [{ label: 'Tax (₹)', data: monthlyTax, backgroundColor: 'rgba(245,158,11,0.7)', borderColor:'#f59e0b', borderWidth:2, borderRadius:6 }]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins:{legend:{display:false}}, scales:{y:{beginAtZero:true}} }
    });
}

function renderReportCharts() {
    const now = new Date();
    const yearSlips = currentSlips.filter(s => s.year == now.getFullYear());

    // Line chart: gross vs net per month
    const grossData = Array(12).fill(0).map((_,i) => yearSlips.filter(s=>s.month==i+1).reduce((a,s)=>a+(s.grossSalary||0),0));
    const netData = Array(12).fill(0).map((_,i) => yearSlips.filter(s=>s.month==i+1).reduce((a,s)=>a+(s.netSalary||0),0));

    destroyChart('reportLineChart');
    const ctx1 = document.getElementById('reportLineChart').getContext('2d');
    chartInstances['reportLineChart'] = new Chart(ctx1, {
        type: 'line',
        data: {
            labels: MONTHS.slice(1),
            datasets: [
                { label: 'Gross Salary', data: grossData, borderColor: '#2563eb', backgroundColor: 'rgba(37,99,235,0.1)', tension:0.4, fill:true },
                { label: 'Net Salary', data: netData, borderColor: '#10b981', backgroundColor: 'rgba(16,185,129,0.1)', tension:0.4, fill:true }
            ]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins:{legend:{position:'bottom'}}, scales:{y:{beginAtZero:true}} }
    });

    // Doughnut: total salary components
    const totalBasic = yearSlips.reduce((a,s)=>a+(s.basicSalary||0),0);
    const totalAllow = yearSlips.reduce((a,s)=>a+(s.allowances||0),0);
    const totalTax = yearSlips.reduce((a,s)=>a+(s.taxAmount||0),0);
    const totalDed = yearSlips.reduce((a,s)=>a+(s.deductions||0),0);

    destroyChart('reportDoughnutChart');
    const ctx2 = document.getElementById('reportDoughnutChart').getContext('2d');
    chartInstances['reportDoughnutChart'] = new Chart(ctx2, {
        type: 'doughnut',
        data: {
            labels: ['Basic Salary','Allowances','Tax','Other Deductions'],
            datasets: [{ data: [totalBasic,totalAllow,totalTax,totalDed], backgroundColor:['#2563eb','#10b981','#f59e0b','#ef4444'], borderWidth:3 }]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins:{legend:{position:'bottom'}} }
    });
}

// ---- EDIT SLIP ----
function openEditModal(id) {
    const slip = currentSlips.find(s => s.id == id);
    if (!slip) return;
    editingSlipId = id;
    document.getElementById('editSlipId').value = id;
    document.getElementById('editWorkingHours').value = slip.workingHours;
    document.getElementById('editSalaryPerHour').value = slip.salaryPerHour;
    document.getElementById('editAllowances').value = slip.allowances || 0;
    document.getElementById('editDeductions').value = slip.deductions || 0;
    document.getElementById('editTaxPercentage').value = slip.taxPercentage || 0;
    document.getElementById('editPreviewNet').textContent = fmt(slip.netSalary);
    document.getElementById('editPreviewTax').textContent = fmt(slip.taxAmount);
    document.getElementById('editSlipModal').classList.remove('hidden');
}

function closeEditModal() {
    document.getElementById('editSlipModal').classList.add('hidden');
    editingSlipId = null;
}

function updateSlip(e) {
    e.preventDefault();
    const idx = currentSlips.findIndex(s => s.id == editingSlipId);
    if (idx === -1) return;
    const wh = parseFloat(document.getElementById('editWorkingHours').value)||0;
    const sph = parseFloat(document.getElementById('editSalaryPerHour').value)||0;
    const allowances = parseFloat(document.getElementById('editAllowances').value)||0;
    const deductions = parseFloat(document.getElementById('editDeductions').value)||0;
    const taxPct = parseFloat(document.getElementById('editTaxPercentage').value)||0;
    const calc = salaryCalculator.calculateSalarySlip({workingHours:wh,salaryPerHour:sph,allowances,deductions,taxPercentage:taxPct});
    currentSlips[idx] = {...currentSlips[idx], workingHours:wh, salaryPerHour:sph, allowances, deductions, taxPercentage:taxPct, ...calc, updatedAt: new Date().toISOString()};
    saveSlipsToStorage();
    closeEditModal();
    showToast('Salary slip updated!', 'success');
    renderOverview();
    renderHistoryTable(currentSlips);
    populateYearFilter();
}

// ---- DELETE SLIP ----
function deleteSlip(id) {
    if (!confirm('Delete this salary slip? This cannot be undone.')) return;
    currentSlips = currentSlips.filter(s => s.id != id);
    saveSlipsToStorage();
    showToast('Slip deleted.', 'success');
    renderOverview();
    renderHistoryTable(currentSlips);
    populateYearFilter();
}

// ---- VIEW SLIP ----
function viewSlip(id) {
    viewingSlipId = id;
    const slip = currentSlips.find(s => s.id == id);
    if (!slip) return;
    const user = getUser();
    document.getElementById('slipPreviewContent').innerHTML = generateSlipHTML(slip, user);
    document.getElementById('slipPreviewModal').classList.remove('hidden');
}

function closeSlipPreview() {
    document.getElementById('slipPreviewModal').classList.add('hidden');
    viewingSlipId = null;
}

function generateSlipHTML(slip, user) {
    return `
    <div style="font-family:Arial,sans-serif;max-width:640px;margin:0 auto;border:2px solid #2563eb;border-radius:12px;overflow:hidden;">
      <div style="background:linear-gradient(135deg,#2563eb,#7c3aed);color:#fff;padding:24px 28px;">
        <h2 style="margin:0 0 4px 0;">Salary Slip</h2>
        <p style="margin:0;opacity:0.85;">${MONTHS[slip.month]} ${slip.year}</p>
      </div>
      <div style="padding:24px 28px;">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px;background:#f9fafb;border-radius:8px;padding:16px;">
          <div><div style="color:#6b7280;font-size:0.8rem;text-transform:uppercase;font-weight:600;">Employee Name</div><div style="font-weight:600;">${slip.empName||'N/A'}</div></div>
          <div><div style="color:#6b7280;font-size:0.8rem;text-transform:uppercase;font-weight:600;">Employee ID</div><div style="font-weight:600;">${slip.empId||'N/A'}</div></div>
          <div><div style="color:#6b7280;font-size:0.8rem;text-transform:uppercase;font-weight:600;">Designation</div><div>${slip.designation||'N/A'}</div></div>
          <div><div style="color:#6b7280;font-size:0.8rem;text-transform:uppercase;font-weight:600;">Department</div><div>${slip.department||'N/A'}</div></div>
          <div><div style="color:#6b7280;font-size:0.8rem;text-transform:uppercase;font-weight:600;">Pay Period</div><div>${MONTHS[slip.month]} ${slip.year}</div></div>
          <div><div style="color:#6b7280;font-size:0.8rem;text-transform:uppercase;font-weight:600;">Working Hours</div><div>${slip.workingHours} hrs</div></div>
        </div>
        <table style="width:100%;border-collapse:collapse;margin-bottom:16px;">
          <thead><tr style="background:#f3f4f6;"><th style="padding:10px 14px;text-align:left;font-size:0.85rem;color:#374151;">Earnings</th><th style="padding:10px 14px;text-align:right;font-size:0.85rem;color:#374151;">Amount</th></tr></thead>
          <tbody>
            <tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:10px 14px;">Basic Salary (${slip.workingHours}h × ₹${slip.salaryPerHour}/h)</td><td style="padding:10px 14px;text-align:right;">${fmt(slip.basicSalary)}</td></tr>
            <tr style="border-bottom:1px solid #e5e7eb;background:#f9fafb;"><td style="padding:10px 14px;">Allowances</td><td style="padding:10px 14px;text-align:right;color:#10b981;">${fmt(slip.allowances||0)}</td></tr>
            <tr style="background:#e0f2fe;"><td style="padding:10px 14px;font-weight:700;">Gross Salary</td><td style="padding:10px 14px;text-align:right;font-weight:700;color:#2563eb;">${fmt(slip.grossSalary)}</td></tr>
          </tbody>
        </table>
        <table style="width:100%;border-collapse:collapse;margin-bottom:16px;">
          <thead><tr style="background:#f3f4f6;"><th style="padding:10px 14px;text-align:left;font-size:0.85rem;color:#374151;">Deductions</th><th style="padding:10px 14px;text-align:right;font-size:0.85rem;color:#374151;">Amount</th></tr></thead>
          <tbody>
            <tr style="border-bottom:1px solid #e5e7eb;"><td style="padding:10px 14px;">Tax (${slip.taxPercentage}%)</td><td style="padding:10px 14px;text-align:right;color:#ef4444;">${fmt(slip.taxAmount)}</td></tr>
            <tr style="background:#f9fafb;"><td style="padding:10px 14px;">Other Deductions</td><td style="padding:10px 14px;text-align:right;color:#ef4444;">${fmt(slip.deductions||0)}</td></tr>
          </tbody>
        </table>
        <div style="background:linear-gradient(135deg,#2563eb,#7c3aed);color:#fff;border-radius:8px;padding:16px 20px;display:flex;justify-content:space-between;align-items:center;">
          <span style="font-size:1.1rem;font-weight:600;">Net Salary (Take Home)</span>
          <span style="font-size:1.5rem;font-weight:700;">${fmt(slip.netSalary)}</span>
        </div>
        <p style="text-align:center;color:#9ca3af;font-size:0.8rem;margin-top:16px;">Generated on ${new Date().toLocaleDateString('en-IN')} | Salary Management System</p>
      </div>
    </div>`;
}

// ---- DOWNLOAD PDF ----
function downloadSlipPDF(id) {
    const slip = currentSlips.find(s => s.id == id) || currentSlips.find(s => s.id == viewingSlipId);
    if (!slip) return;
    const user = getUser();
    const html = generateSlipHTML(slip, user);
    const printWin = window.open('','_blank');
    printWin.document.write(`<!DOCTYPE html><html><head><title>Salary Slip - ${MONTHS[slip.month]} ${slip.year}</title><style>body{margin:0;padding:20px;background:#fff;}</style></head><body>${html}<script>window.onload=function(){window.print();window.close();}<\/script></body></html>`);
    printWin.document.close();
}

function downloadCurrentSlip() {
    if (viewingSlipId) downloadSlipPDF(viewingSlipId);
}

// ---- DOWNLOAD FILES ----
function downloadTaxFile() {
    const now = new Date();
    const yearSlips = currentSlips.filter(s => s.year == now.getFullYear());
    let csv = 'Employee Name,Employee ID,Period,Taxable Amount,Tax Rate (%),Tax Amount,Status\n';
    yearSlips.forEach(s => {
        csv += `${s.empName||''},${s.empId||''},${MONTHS[s.month]} ${s.year},${s.grossSalary||0},${s.taxPercentage||0},${s.taxAmount||0},Paid\n`;
    });
    downloadCSV(csv, 'tax_records.csv');
}

function generateReport() {
    const year = document.getElementById('reportYear').value;
    const month = parseInt(document.getElementById('reportMonth').value);
    const filtered = month ? currentSlips.filter(s=>s.year==year&&s.month==month) : currentSlips.filter(s=>s.year==year);
    if (filtered.length === 0) { showToast('No data for selected period', 'error'); return; }
    const totalGross = filtered.reduce((a,s)=>a+(s.grossSalary||0),0);
    const totalTax = filtered.reduce((a,s)=>a+(s.taxAmount||0),0);
    const totalNet = filtered.reduce((a,s)=>a+(s.netSalary||0),0);
    const html = `<html><head><title>Salary Report</title></head><body style="font-family:Arial;padding:20px;">
      <h1>Salary Report - ${month?MONTHS[month]:''} ${year}</h1>
      <p>Generated: ${new Date().toLocaleDateString('en-IN')}</p>
      <h3>Summary</h3>
      <table border="1" cellpadding="8" style="border-collapse:collapse;width:100%;">
        <tr style="background:#f3f4f6;"><td><b>Total Gross Salary</b></td><td>${fmt(totalGross)}</td></tr>
        <tr><td><b>Total Tax Deducted</b></td><td>${fmt(totalTax)}</td></tr>
        <tr style="background:#e0f2fe;"><td><b>Total Net Salary</b></td><td>${fmt(totalNet)}</td></tr>
      </table>
      <h3>Details</h3>
      <table border="1" cellpadding="8" style="border-collapse:collapse;width:100%;">
        <thead style="background:#f3f4f6;"><tr><th>Employee</th><th>Period</th><th>Gross</th><th>Tax</th><th>Net</th></tr></thead>
        <tbody>${filtered.map(s=>`<tr><td>${s.empName||''}</td><td>${MONTHS[s.month]} ${s.year}</td><td>${fmt(s.grossSalary)}</td><td>${fmt(s.taxAmount)}</td><td>${fmt(s.netSalary)}</td></tr>`).join('')}</tbody>
      </table>
      <script>window.print();<\/script></body></html>`;
    const w = window.open('','_blank');
    w.document.write(html);
    w.document.close();
}

function downloadBankFile() {
    const year = document.getElementById('reportYear').value;
    const month = parseInt(document.getElementById('reportMonth').value);
    const filtered = month ? currentSlips.filter(s=>s.year==year&&s.month==month) : currentSlips.filter(s=>s.year==year);
    let csv = 'Employee Name,Employee ID,Period,Net Salary,Bank Account,IFSC,Transfer Date,Status\n';
    filtered.forEach(s => {
        csv += `${s.empName||''},${s.empId||''},${MONTHS[s.month]} ${s.year},${s.netSalary||0},,,${new Date().toLocaleDateString('en-IN')},Pending\n`;
    });
    downloadCSV(csv, 'bank_transfers.csv');
}

function downloadCSV(content, filename) {
    const blob = new Blob([content], {type:'text/csv'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click();
    document.body.removeChild(a); URL.revokeObjectURL(url);
}

// ---- PROFILE ----
function saveProfile(e) {
    e.preventDefault();
    const user = getUser();
    const updated = {
        ...user,
        name: document.getElementById('profileName').value,
        designation: document.getElementById('profileDesignation').value,
        department: document.getElementById('profileDepartment').value,
        phone: document.getElementById('profilePhone').value,
        salaryPerHour: parseFloat(document.getElementById('profileSalaryPerHour').value)||0
    };
    if (localStorage.getItem('sms_user')) localStorage.setItem('sms_user', JSON.stringify(updated));
    else sessionStorage.setItem('sms_user', JSON.stringify(updated));
    loadUser();
    showToast('Profile updated!', 'success');
}

// ---- LOGOUT ----
function logout() {
    localStorage.removeItem('sms_user');
    sessionStorage.removeItem('sms_user');
    window.location.href = '../index.html';
}

// ---- SIDEBAR ----
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
}

// ---- TOAST ----
function showToast(msg, type='info') {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.className = `toast ${type}`;
    t.classList.remove('hidden');
    setTimeout(() => t.classList.add('hidden'), 3000);
}

// ---- FORMAT ----
function fmt(val) {
    return '₹' + (val||0).toLocaleString('en-IN', {minimumFractionDigits:2, maximumFractionDigits:2});
}
