// ====================================
// SALARY CALCULATOR MODULE
// ====================================

class SalaryCalculator {
    constructor() {
        this.taxRates = {
            '0-250000': 0,
            '250001-500000': 5,
            '500001-1000000': 10,
            '1000001-': 20
        };
    }

    /**
     * Calculate gross salary
     * @param {number} workingHours - Total working hours
     * @param {number} salaryPerHour - Salary per hour
     * @param {number} allowances - Monthly allowances
     * @returns {number} Gross salary
     */
    calculateGrossSalary(workingHours, salaryPerHour, allowances = 0) {
        const basicSalary = workingHours * salaryPerHour;
        return basicSalary + allowances;
    }

    /**
     * Calculate tax amount
     * @param {number} taxableAmount - Amount subject to tax
     * @param {number} taxPercentage - Tax percentage (0-100)
     * @returns {number} Tax amount
     */
    calculateTax(taxableAmount, taxPercentage) {
        return (taxableAmount * taxPercentage) / 100;
    }

    /**
     * Calculate net salary
     * @param {number} grossSalary - Gross salary
     * @param {number} taxAmount - Tax deduction
     * @param {number} deductions - Other deductions
     * @returns {number} Net salary
     */
    calculateNetSalary(grossSalary, taxAmount, deductions = 0) {
        return grossSalary - taxAmount - deductions;
    }

    /**
     * Calculate complete salary slip
     * @param {object} data - Salary data
     * @returns {object} Complete salary breakdown
     */
    calculateSalarySlip(data) {
        const {
            workingHours,
            salaryPerHour,
            allowances = 0,
            deductions = 0,
            taxPercentage = 0
        } = data;

        // Calculate basic and gross salary
        const basicSalary = workingHours * salaryPerHour;
        const grossSalary = basicSalary + allowances;

        // Calculate tax
        const taxableAmount = grossSalary - (deductions || 0);
        const taxAmount = this.calculateTax(grossSalary, taxPercentage);

        // Calculate net salary
        const netSalary = this.calculateNetSalary(grossSalary, taxAmount, deductions);

        return {
            basicSalary: this.roundToTwo(basicSalary),
            allowances: this.roundToTwo(allowances),
            grossSalary: this.roundToTwo(grossSalary),
            taxPercentage,
            taxAmount: this.roundToTwo(taxAmount),
            deductions: this.roundToTwo(deductions),
            netSalary: this.roundToTwo(netSalary),
            takehomeAmount: this.roundToTwo(netSalary)
        };
    }

    /**
     * Calculate salary summary
     * @param {array} slips - Array of salary slips
     * @returns {object} Summary statistics
     */
    calculateSalarySummary(slips) {
        if (!Array.isArray(slips) || slips.length === 0) {
            return this.getEmptySummary();
        }

        const totals = {
            totalGrossSalary: 0,
            totalTax: 0,
            totalDeductions: 0,
            totalNetSalary: 0,
            averageSalary: 0,
            highestSalary: 0,
            lowestSalary: 0
        };

        let netSalaries = [];

        slips.forEach(slip => {
            totals.totalGrossSalary += slip.grossSalary || 0;
            totals.totalTax += slip.taxAmount || 0;
            totals.totalDeductions += slip.deductions || 0;
            totals.totalNetSalary += slip.netSalary || 0;

            if (slip.netSalary) {
                netSalaries.push(slip.netSalary);
            }
        });

        // Calculate averages and extremes
        if (netSalaries.length > 0) {
            totals.averageSalary = this.roundToTwo(totals.totalNetSalary / netSalaries.length);
            totals.highestSalary = Math.max(...netSalaries);
            totals.lowestSalary = Math.min(...netSalaries);
        }

        return {
            ...totals,
            totalGrossSalary: this.roundToTwo(totals.totalGrossSalary),
            totalTax: this.roundToTwo(totals.totalTax),
            totalDeductions: this.roundToTwo(totals.totalDeductions),
            totalNetSalary: this.roundToTwo(totals.totalNetSalary),
            averageSalary: this.roundToTwo(totals.averageSalary),
            highestSalary: this.roundToTwo(totals.highestSalary),
            lowestSalary: this.roundToTwo(totals.lowestSalary),
            slipCount: slips.length
        };
    }

    /**
     * Calculate annual statistics
     * @param {array} monthlySalaries - Array of monthly salary data
     * @returns {object} Annual statistics
     */
    calculateAnnualStatistics(monthlySalaries) {
        if (!Array.isArray(monthlySalaries) || monthlySalaries.length === 0) {
            return this.getEmptySummary();
        }

        let annualGross = 0;
        let annualTax = 0;
        let annualDeductions = 0;
        let annualNet = 0;

        monthlySalaries.forEach(month => {
            annualGross += month.totalGrossSalary || 0;
            annualTax += month.totalTax || 0;
            annualDeductions += month.totalDeductions || 0;
            annualNet += month.totalNetSalary || 0;
        });

        return {
            annualGrossSalary: this.roundToTwo(annualGross),
            annualTaxDeduction: this.roundToTwo(annualTax),
            annualOtherDeductions: this.roundToTwo(annualDeductions),
            annualNetSalary: this.roundToTwo(annualNet),
            monthlyAverage: this.roundToTwo(annualNet / 12),
            taxPercentage: this.roundToTwo((annualTax / annualGross) * 100)
        };
    }

    /**
     * Calculate deduction breakdown
     * @param {object} data - Deduction data
     * @returns {object} Deduction summary
     */
    calculateDeductions(data) {
        const {
            basicSalary = 0,
            providentFund = 0,
            insurancePremium = 0,
            otherDeductions = 0
        } = data;

        const totalDeductions = providentFund + insurancePremium + otherDeductions;

        return {
            basicSalary: this.roundToTwo(basicSalary),
            providentFund: this.roundToTwo(providentFund),
            insurancePremium: this.roundToTwo(insurancePremium),
            otherDeductions: this.roundToTwo(otherDeductions),
            totalDeductions: this.roundToTwo(totalDeductions),
            deductionPercentage: this.roundToTwo((totalDeductions / basicSalary) * 100)
        };
    }

    /**
     * Get applicable tax rate based on income
     * @param {number} income - Annual income
     * @returns {number} Tax percentage
     */
    getTaxRate(income) {
        if (income <= 250000) return 0;
        if (income <= 500000) return 5;
        if (income <= 1000000) return 10;
        return 20;
    }

    /**
     * Format currency value
     * @param {number} value - Value to format
     * @param {string} currency - Currency code (default: INR)
     * @returns {string} Formatted currency string
     */
    formatCurrency(value, currency = 'INR') {
        const formatter = new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: currency,
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
        return formatter.format(value);
    }

    /**
     * Round number to two decimal places
     * @param {number} value - Value to round
     * @returns {number} Rounded value
     */
    roundToTwo(value) {
        return Math.round(value * 100) / 100;
    }

    /**
     * Get empty summary object
     * @returns {object} Empty summary
     */
    getEmptySummary() {
        return {
            totalGrossSalary: 0,
            totalTax: 0,
            totalDeductions: 0,
            totalNetSalary: 0,
            averageSalary: 0,
            highestSalary: 0,
            lowestSalary: 0
        };
    }

    /**
     * Validate salary data
     * @param {object} data - Salary data to validate
     * @returns {object} Validation result
     */
    validateSalaryData(data) {
        const errors = [];

        if (!data.workingHours || data.workingHours <= 0) {
            errors.push('Working hours must be greater than 0');
        }

        if (!data.salaryPerHour || data.salaryPerHour <= 0) {
            errors.push('Salary per hour must be greater than 0');
        }

        if (data.taxPercentage < 0 || data.taxPercentage > 100) {
            errors.push('Tax percentage must be between 0 and 100');
        }

        if ((data.deductions || 0) < 0) {
            errors.push('Deductions cannot be negative');
        }

        return {
            isValid: errors.length === 0,
            errors
        };
    }

    /**
     * Generate salary report data
     * @param {array} slips - Array of salary slips
     * @param {number} year - Year
     * @param {number} month - Month
     * @returns {object} Report data
     */
    generateReportData(slips, year, month) {
        const summary = this.calculateSalarySummary(slips);

        return {
            reportDate: new Date().toLocaleDateString('en-IN'),
            period: `${month}/${year}`,
            summary,
            details: slips.map(slip => ({
                employeeName: slip.employeeName,
                employeeId: slip.employeeId,
                basicSalary: this.roundToTwo(slip.basicSalary),
                allowances: this.roundToTwo(slip.allowances),
                grossSalary: this.roundToTwo(slip.grossSalary),
                taxAmount: this.roundToTwo(slip.taxAmount),
                deductions: this.roundToTwo(slip.deductions),
                netSalary: this.roundToTwo(slip.netSalary)
            }))
        };
    }
}

// Create global calculator instance
const salaryCalculator = new SalaryCalculator();
