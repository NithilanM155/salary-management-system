// ====================================
// API COMMUNICATION MODULE
// ====================================

class API {
    constructor() {
        this.baseUrl = 'http://localhost:8080/salary-management';
        this.user = this.getUser();
        this.token = this.user?.token || null;
    }

    getUser() {
        const user = localStorage.getItem('user') || sessionStorage.getItem('user');
        return user ? JSON.parse(user) : null;
    }

    getHeaders() {
        const headers = {
            'Content-Type': 'application/json',
        };

        if (this.token) {
            headers['Authorization'] = `Bearer ${this.token}`;
        }

        return headers;
    }

    async get(endpoint) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                method: 'GET',
                headers: this.getHeaders()
            });

            if (response.status === 401) {
                this.handleUnauthorized();
            }

            return await response.json();
        } catch (error) {
            console.error('GET request error:', error);
            return { success: false, error: error.message };
        }
    }

    async post(endpoint, data) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                method: 'POST',
                headers: this.getHeaders(),
                body: JSON.stringify(data)
            });

            if (response.status === 401) {
                this.handleUnauthorized();
            }

            return await response.json();
        } catch (error) {
            console.error('POST request error:', error);
            return { success: false, error: error.message };
        }
    }

    async put(endpoint, data) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                method: 'PUT',
                headers: this.getHeaders(),
                body: JSON.stringify(data)
            });

            if (response.status === 401) {
                this.handleUnauthorized();
            }

            return await response.json();
        } catch (error) {
            console.error('PUT request error:', error);
            return { success: false, error: error.message };
        }
    }

    async delete(endpoint) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                method: 'DELETE',
                headers: this.getHeaders()
            });

            if (response.status === 401) {
                this.handleUnauthorized();
            }

            return await response.json();
        } catch (error) {
            console.error('DELETE request error:', error);
            return { success: false, error: error.message };
        }
    }

    async downloadFile(endpoint, filename) {
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${this.token}`
                }
            });

            if (response.status === 401) {
                this.handleUnauthorized();
            }

            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = filename || 'download';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            window.URL.revokeObjectURL(url);

            return { success: true };
        } catch (error) {
            console.error('Download error:', error);
            return { success: false, error: error.message };
        }
    }

    handleUnauthorized() {
        localStorage.removeItem('user');
        sessionStorage.removeItem('user');
        window.location.href = '../index.html';
    }

    // ====================================
    // EMPLOYEE ENDPOINTS
    // ====================================

    async getEmployeeProfile() {
        return this.get('/api/employee/profile');
    }

    async updateEmployeeProfile(data) {
        return this.post('/api/employee/profile', data);
    }

    async createSalarySlip(data) {
        return this.post('/api/salary/create-slip', data);
    }

    async getSalarySlips(employeeId = null) {
        const endpoint = employeeId 
            ? `/api/salary/slips/${employeeId}`
            : '/api/salary/slips';
        return this.get(endpoint);
    }

    async getSalarySlip(slipId) {
        return this.get(`/api/salary/slip/${slipId}`);
    }

    async updateSalarySlip(slipId, data) {
        return this.put(`/api/salary/slip/${slipId}`, data);
    }

    async downloadSalarySlipPDF(slipId) {
        return this.downloadFile(`/api/salary/slip/${slipId}/download`, 'salary_slip.pdf');
    }

    async getSalaryData(employeeId = null) {
        const endpoint = employeeId 
            ? `/api/salary/data/${employeeId}`
            : '/api/salary/data';
        return this.get(endpoint);
    }

    async getTaxData(employeeId = null) {
        const endpoint = employeeId 
            ? `/api/tax/data/${employeeId}`
            : '/api/tax/data';
        return this.get(endpoint);
    }

    // ====================================
    // ADMIN ENDPOINTS
    // ====================================

    async getAdminDashboard() {
        return this.get('/api/admin/dashboard');
    }

    async getAllEmployees() {
        return this.get('/api/admin/employees');
    }

    async getEmployee(employeeId) {
        return this.get(`/api/admin/employee/${employeeId}`);
    }

    async createEmployee(data) {
        return this.post('/api/admin/employee', data);
    }

    async updateEmployee(employeeId, data) {
        return this.put(`/api/admin/employee/${employeeId}`, data);
    }

    async deleteEmployee(employeeId) {
        return this.delete(`/api/admin/employee/${employeeId}`);
    }

    async getAllSalarySlips() {
        return this.get('/api/admin/salary-slips');
    }

    async generateTaxFile() {
        return this.downloadFile('/api/admin/generate-tax-file', 'tax_records.csv');
    }

    async generateBankFile() {
        return this.downloadFile('/api/admin/generate-bank-file', 'bank_transfers.csv');
    }

    async getOrganizationSettings() {
        return this.get('/api/admin/settings');
    }

    async updateOrganizationSettings(data) {
        return this.post('/api/admin/settings', data);
    }

    // ====================================
    // STATISTICS & REPORTS
    // ====================================

    async getMonthlyStatistics(year, month) {
        return this.get(`/api/statistics/monthly/${year}/${month}`);
    }

    async getAnnualStatistics(year) {
        return this.get(`/api/statistics/annual/${year}`);
    }

    async getTaxSummary(year) {
        return this.get(`/api/tax/summary/${year}`);
    }

    async getSalaryReport(year, month) {
        return this.downloadFile(`/api/reports/salary/${year}/${month}`, 
            `salary_report_${year}_${month}.pdf`);
    }
}

// Create global API instance
const api = new API();
