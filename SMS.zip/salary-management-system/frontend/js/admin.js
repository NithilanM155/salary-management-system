// ====================================
// ADMIN MODULE - Uses localStorage
// ====================================

const ADMIN_EMAIL = 'admin@salary.com';
const ADMIN_PASSWORD = 'admin123';
const MONTHS_A = ['','January','February','March','April','May','June',
                  'July','August','September','October','November','December'];

document.addEventListener('DOMContentLoaded', () => {
    checkAdminAuth();
    document.getElementById('adminCurrentDate').textContent = new Date().toLocaleDateString('en-IN',{weekday:'long',year:'numeric',month:'long',day:'numeric'});
    loadAdminOverview();

    document.getElementById('addEmployeeForm').addEventListener('submit', addEmployee);
    document.getElementById('editEmployeeForm').addEventListener('submit', editEmployee);
    document.getElementById('orgSettingsForm').addEventListener('submit', saveSettings);
    document.getElementById('changePasswordForm').addEventListener('submit', changePassword);

    showSection('admin-overview');
});

function checkAdminAuth() {
    const u = localStorage.getItem('sms_user') || sessionStorage.getItem('sms_user');
    if (!u) { window.location.href = '../index.html'; return; }
    const user = JSON.parse(u);
    if (user.role !== 'admin') { window.location.href = 'dashboard.html'; }
}

function getAdminUser() {
    const u = localStorage.getItem('sms_user') || sessionStorage.getItem('sms_user');
    return u ? JSON.parse(u) : null;
}

// ---- SECTIONS ----
function showSection(name) {
    document.querySelectorAll('.content > section').forEach(s => s.classList.add('hidden'));
    document.getElementById(`section-${name}`).classList.remove('hidden');
    document.getElementById('adminPageTitle').textContent = {
        'admin-overview': 'Admin Overview',
        'employees': 'Employees',
        'all-slips': 'All Salary Slips',
        'admin-tax': 'Tax Management',
        'admin-reports': 'Reports',
        'settings': 'Settings'
    }[name] || name;
    document.querySelectorAll('.sidebar-nav a').forEach(a => a.classList.remove('active'));
    const secs = ['admin-overview','employees','all-slips','admin-tax','admin-reports','settings'];
    const idx = secs.indexOf(name);
    const links = document.querySelectorAll('.sidebar-nav a');
    if (links[idx]) links[idx].classList.add('active');

    if (name === 'admin-overview') loadAdminOverview();
    if (name === 'employees') loadEmployees();
    if (name === 'all-slips') loadAllSlips();
    if (name === 'admin-tax') loadAdminTax();
    if (name === 'admin-reports') loadAdminReports();
    if (name === 'settings') loadSettings();
}

// ---- GET ALL DATA ----
function getAllSlips() {
    const keys = Object.keys(localStorage).filter(k => k.startsWith('sms_slips_'));
    let all = [];
    keys.forEach(k => {
        try { all = all.concat(JSON.parse(localStorage.getItem(k))||[]); } catch(e){}
    });
    return all;
}

function getAllUsers() {
    const data = localStorage.getItem('sms_all_users');
    return data ? JSON.parse(data) : [];
}

function saveAllUsers(users) {
    localStorage.setItem('sms_all_users', JSON.stringify(users));
}

// ---- OVERVIEW ----
function loadAdminOverview() {
    const users = getAllUsers().filter(u => u.role !== 'admin');
    const allSlips = getAllSlips();
    const now = new Date();
    const monthSlips = allSlips.filter(s => s.month == now.getMonth()+1 && s.year == now.getFullYear());
    const yearSlips = allSlips.filter(s => s.year == now.getFullYear());

    document.getElementById('adminStatEmployees').textContent = users.length;
    document.getElementById('adminStatMonthlySalary').textContent = '₹' + monthSlips.reduce((a,s)=>a+(s.netSalary||0),0).toLocaleString('en-IN',{minimumFractionDigits:2});
    document.getElementById('adminStatAnnualTax').textContent = '₹' + yearSlips.reduce((a,s)=>a+(s.taxAmount||0),0).toLocaleString('en-IN',{minimumFractionDigits:2});
    document.getElementById('adminStatAnnualSalary').textContent = '₹' + yearSlips.reduce((a,s)=>a+(s.netSalary||0),0).toLocaleString('en-IN',{minimumFractionDigits:2});

    renderAdminCharts(yearSlips);
}

// ---- CHARTS ----
let adminCharts = {};
function destroyAdminChart(id) {
    if (adminCharts[id]) { adminCharts[id].destroy(); delete adminCharts[id]; }
}

function renderAdminCharts(slips) {
    const monthlyNet = Array(12).fill(0).map((_,i)=>slips.filter(s=>s.month==i+1).reduce((a,s)=>a+(s.netSalary||0),0));

    destroyAdminChart('adminMonthlyChart');
    const ctx1 = document.getElementById('adminMonthlyChart').getContext('2d');
    adminCharts['adminMonthlyChart'] = new Chart(ctx1, {
        type:'bar',
        data:{labels:MONTHS_A.slice(1),datasets:[{label:'Total Net Salary',data:monthlyNet,backgroundColor:'rgba(37,99,235,0.7)',borderColor:'#2563eb',borderWidth:2,borderRadius:6}]},
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{callback:v=>'₹'+v.toLocaleString('en-IN')}}}}
    });

    const totalNet = slips.reduce((a,s)=>a+(s.netSalary||0),0);
    const totalTax = slips.reduce((a,s)=>a+(s.taxAmount||0),0);
    const totalDed = slips.reduce((a,s)=>a+(s.deductions||0),0);

    destroyAdminChart('adminPieChart');
    const ctx2 = document.getElementById('adminPieChart').getContext('2d');
    adminCharts['adminPieChart'] = new Chart(ctx2, {
        type:'doughnut',
        data:{labels:['Net Salary','Tax','Other Deductions'],datasets:[{data:[totalNet,totalTax,totalDed],backgroundColor:['#2563eb','#f59e0b','#ef4444'],borderWidth:3}]},
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom'}}}
    });
}

// ---- EMPLOYEES ----
function loadEmployees() {
    const users = getAllUsers().filter(u => u.role !== 'admin');
    const tbody = document.getElementById('employeeTableBody');
    if (users.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center" style="padding:2rem;color:#9ca3af;">No employees registered yet.</td></tr>';
        return;
    }
    tbody.innerHTML = users.map((u,i) => `
        <tr>
            <td>${i+1}</td>
            <td><strong>${u.name||'N/A'}</strong></td>
            <td>${u.email||'N/A'}</td>
            <td>${u.designation||'N/A'}</td>
            <td>${u.department||'N/A'}</td>
            <td>₹${(u.salaryPerHour||0).toLocaleString('en-IN')}</td>
            <td>${u.createdAt ? new Date(u.createdAt).toLocaleDateString('en-IN') : 'N/A'}</td>
            <td>
                <div class="action-buttons">
                    <button class="action-btn edit" onclick="openEditEmployeeModal('${u.email}')">✏ Edit</button>
                    <button class="action-btn delete" onclick="deleteEmployee('${u.email}')">🗑 Delete</button>
                    <button class="action-btn download" onclick="viewEmployeeSlips('${u.email}')">📋 Slips</button>
                </div>
            </td>
        </tr>`).join('');
}

// ---- ADD EMPLOYEE ----
function openAddEmployeeModal() {
    document.getElementById('addEmployeeModal').classList.remove('hidden');
}
function closeAddEmployeeModal() {
    document.getElementById('addEmployeeModal').classList.add('hidden');
    document.getElementById('addEmployeeForm').reset();
}

function addEmployee(e) {
    e.preventDefault();
    const email = document.getElementById('newEmpEmail').value;
    const users = getAllUsers();
    if (users.find(u => u.email === email)) {
        showAdminToast('Email already exists!', 'error');
        return;
    }
    const newUser = {
        email,
        name: document.getElementById('newEmpName').value,
        password: document.getElementById('newEmpPassword').value,
        designation: document.getElementById('newEmpDesignation').value,
        department: document.getElementById('newEmpDepartment').value,
        salaryPerHour: parseFloat(document.getElementById('newEmpSalaryPerHour').value)||0,
        dateOfJoining: document.getElementById('newEmpJoiningDate').value,
        role: 'employee',
        createdAt: new Date().toISOString()
    };
    users.push(newUser);
    saveAllUsers(users);
    closeAddEmployeeModal();
    showAdminToast('Employee added successfully!', 'success');
    loadEmployees();
}

// ---- EDIT EMPLOYEE ----
function openEditEmployeeModal(email) {
    const users = getAllUsers();
    const u = users.find(u => u.email === email);
    if (!u) return;
    document.getElementById('editEmpId').value = email;
    document.getElementById('editEmpName').value = u.name||'';
    document.getElementById('editEmpDesignation').value = u.designation||'';
    document.getElementById('editEmpDepartment').value = u.department||'';
    document.getElementById('editEmpSalaryPerHour').value = u.salaryPerHour||0;
    document.getElementById('editEmployeeModal').classList.remove('hidden');
}
function closeEditEmployeeModal() {
    document.getElementById('editEmployeeModal').classList.add('hidden');
}

function editEmployee(e) {
    e.preventDefault();
    const email = document.getElementById('editEmpId').value;
    const users = getAllUsers();
    const idx = users.findIndex(u => u.email === email);
    if (idx === -1) return;
    users[idx] = {
        ...users[idx],
        name: document.getElementById('editEmpName').value,
        designation: document.getElementById('editEmpDesignation').value,
        department: document.getElementById('editEmpDepartment').value,
        salaryPerHour: parseFloat(document.getElementById('editEmpSalaryPerHour').value)||0
    };
    saveAllUsers(users);
    closeEditEmployeeModal();
    showAdminToast('Employee updated!', 'success');
    loadEmployees();
}

function deleteEmployee(email) {
    if (!confirm('Delete this employee and all their data?')) return;
    const users = getAllUsers().filter(u => u.email !== email);
    saveAllUsers(users);
    localStorage.removeItem(`sms_slips_${email}`);
    showAdminToast('Employee deleted.', 'success');
    loadEmployees();
}

function viewEmployeeSlips(email) {
    const slips = JSON.parse(localStorage.getItem(`sms_slips_${email}`)||'[]');
    alert(`Employee ${email} has ${slips.length} salary slips.\nTotal Net: ₹${slips.reduce((a,s)=>a+(s.netSalary||0),0).toLocaleString('en-IN')}`);
}

// ---- ALL SLIPS ----
function loadAllSlips() {
    const allSlips = getAllSlips();
    const year = document.getElementById('adminFilterYear').value;
    const month = document.getElementById('adminFilterMonth').value;
    let filtered = [...allSlips];
    if (year) filtered = filtered.filter(s=>s.year==year);
    if (month) filtered = filtered.filter(s=>s.month==month);
    filtered.sort((a,b)=>(b.year*100+b.month)-(a.year*100+a.month));

    const tbody = document.getElementById('allSlipsBody');
    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center" style="padding:2rem;color:#9ca3af;">No salary slips found.</td></tr>';
        return;
    }
    tbody.innerHTML = filtered.map((s,i)=>`
        <tr>
            <td>${i+1}</td>
            <td>${s.empName||'N/A'}<br><small style="color:#9ca3af;">${s.empId||''}</small></td>
            <td>${MONTHS_A[s.month]} ${s.year}</td>
            <td>₹${(s.grossSalary||0).toLocaleString('en-IN',{minimumFractionDigits:2})}</td>
            <td>₹${(s.taxAmount||0).toLocaleString('en-IN',{minimumFractionDigits:2})}</td>
            <td><strong>₹${(s.netSalary||0).toLocaleString('en-IN',{minimumFractionDigits:2})}</strong></td>
            <td><span class="badge badge-success">${s.status||'finalized'}</span></td>
            <td>
                <div class="action-buttons">
                    <button class="action-btn download" onclick="adminDownloadSlip(${JSON.stringify(s).replace(/"/g,"&quot;")})">⬇ PDF</button>
                </div>
            </td>
        </tr>`).join('');
}

function adminDownloadSlip(slip) {
    const html = generateAdminSlipHTML(slip);
    const w = window.open('','_blank');
    w.document.write(`<!DOCTYPE html><html><head><title>Salary Slip</title><style>body{margin:0;padding:20px;}</style></head><body>${html}<script>window.onload=function(){window.print();window.close();}<\/script></body></html>`);
    w.document.close();
}

function generateAdminSlipHTML(s) {
    return `<div style="font-family:Arial;max-width:640px;margin:0 auto;border:2px solid #2563eb;border-radius:12px;overflow:hidden;">
      <div style="background:linear-gradient(135deg,#2563eb,#7c3aed);color:#fff;padding:24px;"><h2 style="margin:0;">Salary Slip - ${MONTHS_A[s.month]} ${s.year}</h2></div>
      <div style="padding:24px;">
        <table style="width:100%;margin-bottom:16px;border-collapse:collapse;">
          <tr><td style="padding:6px 0;"><b>Employee:</b> ${s.empName||''}</td><td><b>ID:</b> ${s.empId||''}</td></tr>
          <tr><td><b>Designation:</b> ${s.designation||''}</td><td><b>Hours:</b> ${s.workingHours||0}h</td></tr>
        </table>
        <table border="1" cellpadding="8" style="width:100%;border-collapse:collapse;">
          <tr style="background:#f3f4f6;"><td><b>Basic Salary</b></td><td style="text-align:right;">₹${(s.basicSalary||0).toLocaleString('en-IN',{minimumFractionDigits:2})}</td></tr>
          <tr><td>Allowances</td><td style="text-align:right;">₹${(s.allowances||0).toLocaleString('en-IN',{minimumFractionDigits:2})}</td></tr>
          <tr style="background:#dbeafe;"><td><b>Gross Salary</b></td><td style="text-align:right;"><b>₹${(s.grossSalary||0).toLocaleString('en-IN',{minimumFractionDigits:2})}</b></td></tr>
          <tr><td>Tax (${s.taxPercentage||0}%)</td><td style="text-align:right;color:red;">-₹${(s.taxAmount||0).toLocaleString('en-IN',{minimumFractionDigits:2})}</td></tr>
          <tr><td>Other Deductions</td><td style="text-align:right;color:red;">-₹${(s.deductions||0).toLocaleString('en-IN',{minimumFractionDigits:2})}</td></tr>
          <tr style="background:#dcfce7;"><td><b>Net Salary</b></td><td style="text-align:right;"><b style="color:#16a34a;font-size:1.1rem;">₹${(s.netSalary||0).toLocaleString('en-IN',{minimumFractionDigits:2})}</b></td></tr>
        </table>
      </div>
    </div>`;
}

// ---- TAX ----
function loadAdminTax() {
    const allSlips = getAllSlips();
    const now = new Date();
    const yearSlips = allSlips.filter(s=>s.year==now.getFullYear());
    const totalTax = yearSlips.reduce((a,s)=>a+(s.taxAmount||0),0);
    const uniqueEmps = [...new Set(yearSlips.map(s=>s.empId))].length;

    document.getElementById('orgAnnualTax').textContent = '₹'+totalTax.toLocaleString('en-IN',{minimumFractionDigits:2});
    document.getElementById('employeesTaxed').textContent = uniqueEmps;
    document.getElementById('avgTaxPerEmp').textContent = uniqueEmps ? '₹'+(totalTax/uniqueEmps).toLocaleString('en-IN',{minimumFractionDigits:2}) : '₹0.00';

    const tbody = document.getElementById('adminTaxBody');
    if (yearSlips.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center" style="padding:2rem;color:#9ca3af;">No tax records.</td></tr>';
        return;
    }
    tbody.innerHTML = yearSlips.map(s=>`
        <tr>
            <td>${s.empName||''}</td>
            <td>${MONTHS_A[s.month]} ${s.year}</td>
            <td>₹${(s.grossSalary||0).toLocaleString('en-IN',{minimumFractionDigits:2})}</td>
            <td>${s.taxPercentage||0}%</td>
            <td>₹${(s.taxAmount||0).toLocaleString('en-IN',{minimumFractionDigits:2})}</td>
            <td><span class="badge badge-warning">Paid</span></td>
        </tr>`).join('');
}

function adminGenerateTaxFile() {
    const allSlips = getAllSlips();
    let csv = 'Employee Name,Employee ID,Designation,Period,Gross Salary,Tax Rate (%),Tax Amount,Status\n';
    allSlips.forEach(s => {
        csv += `${s.empName||''},${s.empId||''},${s.designation||''},${MONTHS_A[s.month]} ${s.year},${s.grossSalary||0},${s.taxPercentage||0},${s.taxAmount||0},Paid\n`;
    });
    const blob = new Blob([csv],{type:'text/csv'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href=url; a.download='org_tax_file.csv';
    document.body.appendChild(a); a.click();
    document.body.removeChild(a); URL.revokeObjectURL(url);
    showAdminToast('Tax file downloaded!', 'success');
}

function adminGenerateTaxReport() {
    const allSlips = getAllSlips();
    const now = new Date();
    const yearSlips = allSlips.filter(s=>s.year==now.getFullYear());
    const totalTax = yearSlips.reduce((a,s)=>a+(s.taxAmount||0),0);
    const totalGross = yearSlips.reduce((a,s)=>a+(s.grossSalary||0),0);

    const html = `<html><head><title>Tax Report ${now.getFullYear()}</title></head><body style="font-family:Arial;padding:20px;">
      <h1>Annual Tax Report - ${now.getFullYear()}</h1>
      <p>Generated: ${now.toLocaleDateString('en-IN')}</p>
      <table border="1" cellpadding="8" style="border-collapse:collapse;width:100%;margin-bottom:20px;">
        <tr style="background:#f3f4f6;"><th>Metric</th><th>Amount</th></tr>
        <tr><td>Total Gross Salary</td><td>₹${totalGross.toLocaleString('en-IN',{minimumFractionDigits:2})}</td></tr>
        <tr><td>Total Tax Collected</td><td>₹${totalTax.toLocaleString('en-IN',{minimumFractionDigits:2})}</td></tr>
        <tr><td>No. of Employees</td><td>${[...new Set(yearSlips.map(s=>s.empId))].length}</td></tr>
      </table>
      <h3>Detailed Tax Records</h3>
      <table border="1" cellpadding="8" style="border-collapse:collapse;width:100%;">
        <thead style="background:#f3f4f6;"><tr><th>Employee</th><th>Period</th><th>Taxable</th><th>Rate</th><th>Tax</th></tr></thead>
        <tbody>${yearSlips.map(s=>`<tr><td>${s.empName||''}</td><td>${MONTHS_A[s.month]} ${s.year}</td><td>₹${(s.grossSalary||0).toLocaleString('en-IN',{minimumFractionDigits:2})}</td><td>${s.taxPercentage||0}%</td><td>₹${(s.taxAmount||0).toLocaleString('en-IN',{minimumFractionDigits:2})}</td></tr>`).join('')}</tbody>
      </table>
      <script>window.print();<\/script></body></html>`;
    const w = window.open('','_blank'); w.document.write(html); w.document.close();
}

// ---- REPORTS ----
function loadAdminReports() {
    const allSlips = getAllSlips();
    const now = new Date();
    const yearSlips = allSlips.filter(s=>s.year==now.getFullYear());

    // Dept chart
    const depts = {};
    yearSlips.forEach(s=>{
        const d = s.department||'Other';
        depts[d] = (depts[d]||0)+(s.netSalary||0);
    });

    destroyAdminChart('deptSalaryChart');
    const ctx1 = document.getElementById('deptSalaryChart').getContext('2d');
    adminCharts['deptSalaryChart'] = new Chart(ctx1, {
        type:'bar',
        data:{labels:Object.keys(depts),datasets:[{label:'Net Salary',data:Object.values(depts),backgroundColor:'rgba(124,58,237,0.7)',borderColor:'#7c3aed',borderWidth:2,borderRadius:6}]},
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}
    });

    // Monthly org expense
    const monthlyGross = Array(12).fill(0).map((_,i)=>yearSlips.filter(s=>s.month==i+1).reduce((a,s)=>a+(s.grossSalary||0),0));

    destroyAdminChart('orgExpenseChart');
    const ctx2 = document.getElementById('orgExpenseChart').getContext('2d');
    adminCharts['orgExpenseChart'] = new Chart(ctx2, {
        type:'line',
        data:{labels:MONTHS_A.slice(1),datasets:[{label:'Total Gross Salary',data:monthlyGross,borderColor:'#2563eb',backgroundColor:'rgba(37,99,235,0.1)',tension:0.4,fill:true}]},
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}
    });
}

function adminDownloadSalaryReport() {
    const allSlips = getAllSlips();
    const year = document.getElementById('adminReportYear').value;
    const month = parseInt(document.getElementById('adminReportMonth').value);
    const filtered = month ? allSlips.filter(s=>s.year==year&&s.month==month) : allSlips.filter(s=>s.year==year);
    const totalNet = filtered.reduce((a,s)=>a+(s.netSalary||0),0);
    const totalGross = filtered.reduce((a,s)=>a+(s.grossSalary||0),0);
    const totalTax = filtered.reduce((a,s)=>a+(s.taxAmount||0),0);

    const html = `<html><head><title>Salary Report</title></head><body style="font-family:Arial;padding:20px;">
      <h1>Salary Report - ${month?MONTHS_A[month]+' ':''} ${year}</h1>
      <p>Generated: ${new Date().toLocaleDateString('en-IN')}</p>
      <h3>Organization Summary</h3>
      <table border="1" cellpadding="8" style="border-collapse:collapse;width:100%;margin-bottom:20px;">
        <tr style="background:#f3f4f6;"><td><b>Total Gross Salary</b></td><td>₹${totalGross.toLocaleString('en-IN',{minimumFractionDigits:2})}</td></tr>
        <tr><td><b>Total Tax Deducted</b></td><td>₹${totalTax.toLocaleString('en-IN',{minimumFractionDigits:2})}</td></tr>
        <tr style="background:#dcfce7;"><td><b>Total Net Salary</b></td><td>₹${totalNet.toLocaleString('en-IN',{minimumFractionDigits:2})}</td></tr>
      </table>
      <h3>Employee Details</h3>
      <table border="1" cellpadding="8" style="border-collapse:collapse;width:100%;">
        <thead style="background:#f3f4f6;"><tr><th>Employee</th><th>Period</th><th>Gross</th><th>Tax</th><th>Net</th></tr></thead>
        <tbody>${filtered.map(s=>`<tr><td>${s.empName||''} (${s.empId||''})</td><td>${MONTHS_A[s.month]} ${s.year}</td><td>₹${(s.grossSalary||0).toLocaleString('en-IN',{minimumFractionDigits:2})}</td><td>₹${(s.taxAmount||0).toLocaleString('en-IN',{minimumFractionDigits:2})}</td><td>₹${(s.netSalary||0).toLocaleString('en-IN',{minimumFractionDigits:2})}</td></tr>`).join('')}</tbody>
      </table>
      <script>window.print();<\/script></body></html>`;
    const w = window.open('','_blank'); w.document.write(html); w.document.close();
}

function adminDownloadBankFile() {
    const allSlips = getAllSlips();
    const year = document.getElementById('adminReportYear').value;
    const month = parseInt(document.getElementById('adminReportMonth').value);
    const filtered = month ? allSlips.filter(s=>s.year==year&&s.month==month) : allSlips.filter(s=>s.year==year);
    let csv = 'Employee Name,Employee ID,Designation,Period,Net Salary,Bank Account,IFSC,Status\n';
    filtered.forEach(s => {
        csv += `${s.empName||''},${s.empId||''},${s.designation||''},${MONTHS_A[s.month]} ${s.year},${s.netSalary||0},,, Pending\n`;
    });
    const blob = new Blob([csv],{type:'text/csv'});
    const url = URL.createObjectURL(blob); const a = document.createElement('a');
    a.href=url; a.download='bank_transfer.csv'; document.body.appendChild(a); a.click();
    document.body.removeChild(a); URL.revokeObjectURL(url);
    showAdminToast('Bank file downloaded!', 'success');
}

// ---- SETTINGS ----
function loadSettings() {
    const settings = JSON.parse(localStorage.getItem('sms_org_settings')||'{}');
    document.getElementById('orgName').value = settings.orgName||'';
    document.getElementById('orgTaxId').value = settings.orgTaxId||'';
    document.getElementById('orgEmail').value = settings.orgEmail||'';
    document.getElementById('orgPhone').value = settings.orgPhone||'';
    document.getElementById('orgAddress').value = settings.orgAddress||'';
    document.getElementById('orgBankName').value = settings.orgBankName||'';
    document.getElementById('orgBankAccount').value = settings.orgBankAccount||'';
}

function saveSettings(e) {
    e.preventDefault();
    const settings = {
        orgName: document.getElementById('orgName').value,
        orgTaxId: document.getElementById('orgTaxId').value,
        orgEmail: document.getElementById('orgEmail').value,
        orgPhone: document.getElementById('orgPhone').value,
        orgAddress: document.getElementById('orgAddress').value,
        orgBankName: document.getElementById('orgBankName').value,
        orgBankAccount: document.getElementById('orgBankAccount').value
    };
    localStorage.setItem('sms_org_settings', JSON.stringify(settings));
    showAdminToast('Settings saved!', 'success');
}

function changePassword(e) {
    e.preventDefault();
    const cur = document.getElementById('currentPassword').value;
    const newP = document.getElementById('newPassword').value;
    const conf = document.getElementById('confirmNewPassword').value;
    if (cur !== ADMIN_PASSWORD && cur !== (JSON.parse(localStorage.getItem('sms_admin_password')||`"${ADMIN_PASSWORD}"`))) {
        showAdminToast('Current password is incorrect!', 'error'); return;
    }
    if (newP !== conf) { showAdminToast('Passwords do not match!', 'error'); return; }
    if (newP.length < 6) { showAdminToast('Password must be at least 6 characters!', 'error'); return; }
    localStorage.setItem('sms_admin_password', JSON.stringify(newP));
    document.getElementById('changePasswordForm').reset();
    showAdminToast('Password changed successfully!', 'success');
}

// ---- LOGOUT ----
function adminLogout() {
    localStorage.removeItem('sms_user');
    sessionStorage.removeItem('sms_user');
    window.location.href = '../index.html';
}

function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
}

function showAdminToast(msg, type='info') {
    const t = document.getElementById('toast');
    t.textContent = msg; t.className = `toast ${type}`;
    t.classList.remove('hidden');
    setTimeout(()=>t.classList.add('hidden'), 3000);
}
